from django.shortcuts import redirect
from django.urls import reverse, resolve, Resolver404

# URL names that are reachable without being logged in.
EXEMPT_URL_NAMES = {
    'login',
    'webauthn_login_begin',
    'webauthn_login_complete',
}


class LoginRequiredMiddleware:
    """
    Requires an authenticated Django user for every page except the login
    page, the passwordless WebAuthn login endpoints (which run before a
    session exists), static files, and the Django admin (which has its own
    login).
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if self._is_exempt(request):
            return self.get_response(request)

        if not request.user.is_authenticated:
            return redirect(f"{reverse('login')}?next={request.path}")

        return self.get_response(request)

    def _is_exempt(self, request):
        path = request.path
        if path.startswith('/static/') or path.startswith('/admin/'):
            return True
        try:
            match = resolve(path)
        except Resolver404:
            return False
        return match.url_name in EXEMPT_URL_NAMES
