// Small helpers + flows for WebAuthn (passkey) registration and login.
// Requires a browser that supports the Web Authentication API
// (Chrome, Firefox, Safari, Edge — all current versions).

function getCookie(name) {
  const match = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
  return match ? decodeURIComponent(match.pop()) : '';
}

function base64urlToBuffer(base64url) {
  const padded = base64url.replace(/-/g, '+').replace(/_/g, '/').padEnd(
    base64url.length + (4 - (base64url.length % 4)) % 4, '='
  );
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

function bufferToBase64url(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  bytes.forEach(b => binary += String.fromCharCode(b));
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function postJson(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCookie('csrftoken') },
    body: body ? JSON.stringify(body) : '{}',
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ---------- Registration (must already be logged in) ----------
async function registerPasskey(beginUrl, completeUrl, nickname) {
  if (!window.PublicKeyCredential) {
    throw new Error('This browser does not support passkeys.');
  }
  const options = await postJson(beginUrl, {});

  const publicKey = {
    ...options,
    challenge: base64urlToBuffer(options.challenge),
    user: { ...options.user, id: base64urlToBuffer(options.user.id) },
    excludeCredentials: (options.excludeCredentials || []).map(c => ({
      ...c, id: base64urlToBuffer(c.id),
    })),
  };

  const credential = await navigator.credentials.create({ publicKey });

  const payload = {
    id: credential.id,
    rawId: bufferToBase64url(credential.rawId),
    type: credential.type,
    nickname: nickname || '',
    response: {
      clientDataJSON: bufferToBase64url(credential.response.clientDataJSON),
      attestationObject: bufferToBase64url(credential.response.attestationObject),
    },
  };

  return postJson(completeUrl, payload);
}

// ---------- Passwordless login ----------
async function loginWithPasskey(beginUrl, completeUrl) {
  if (!window.PublicKeyCredential) {
    throw new Error('This browser does not support passkeys.');
  }
  const options = await postJson(beginUrl, {});

  const publicKey = {
    ...options,
    challenge: base64urlToBuffer(options.challenge),
    allowCredentials: (options.allowCredentials || []).map(c => ({
      ...c, id: base64urlToBuffer(c.id),
    })),
  };

  const assertion = await navigator.credentials.get({ publicKey });

  const payload = {
    id: assertion.id,
    rawId: bufferToBase64url(assertion.rawId),
    type: assertion.type,
    response: {
      clientDataJSON: bufferToBase64url(assertion.response.clientDataJSON),
      authenticatorData: bufferToBase64url(assertion.response.authenticatorData),
      signature: bufferToBase64url(assertion.response.signature),
      userHandle: assertion.response.userHandle ? bufferToBase64url(assertion.response.userHandle) : null,
    },
  };

  return postJson(completeUrl, payload);
}
