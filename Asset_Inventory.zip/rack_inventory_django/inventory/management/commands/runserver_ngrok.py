"""
Starts an ngrok tunnel to this app using YOUR OWN ngrok API key (authtoken),
prints the public URL, sets PUBLIC_ORIGIN for this process so
ALLOWED_HOSTS/CSRF/WebAuthn all recognize it automatically, and then starts
the normal Django dev server.

Usage:
    export NGROK_AUTHTOKEN=your_token_here    (get one at
        https://dashboard.ngrok.com/get-started/your-authtoken)
    pip install pyngrok
    python manage.py runserver_ngrok            # defaults to port 8000
    python manage.py runserver_ngrok 8080        # or a different port

This project never stores or transmits an ngrok key on your behalf — it
only reads NGROK_AUTHTOKEN from your own environment and hands it straight
to the official `pyngrok` library, which talks to ngrok's service directly
from your machine.
"""
import os

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = 'Starts an ngrok tunnel (using NGROK_AUTHTOKEN) and runs the dev server through it.'

    def add_arguments(self, parser):
        parser.add_argument('port', nargs='?', default='8000')

    def handle(self, *args, **options):
        try:
            from pyngrok import conf, ngrok
        except ImportError:
            self.stderr.write(self.style.ERROR(
                "pyngrok isn't installed. Run: pip install pyngrok"
            ))
            return

        token = os.environ.get('NGROK_AUTHTOKEN')
        if not token:
            self.stderr.write(self.style.ERROR(
                'Set your ngrok API key first, then try again:\n'
                '  export NGROK_AUTHTOKEN=your_token_here     (macOS/Linux)\n'
                '  setx NGROK_AUTHTOKEN "your_token_here"      (Windows, new terminal after)\n'
                'Get a key at https://dashboard.ngrok.com/get-started/your-authtoken'
            ))
            return

        port = options['port']
        conf.get_default().auth_token = token
        tunnel = ngrok.connect(str(port), 'http')
        public_url = tunnel.public_url.replace('http://', 'https://', 1)

        # So ALLOWED_HOSTS / CSRF_TRUSTED_ORIGINS / WEBAUTHN_* pick this up
        # for the rest of this process, exactly as if you'd set
        # PUBLIC_ORIGIN yourself before starting the server.
        os.environ['PUBLIC_ORIGIN'] = public_url
        host = public_url.split('://')[-1]
        if host not in settings.ALLOWED_HOSTS and '*' not in settings.ALLOWED_HOSTS:
            settings.ALLOWED_HOSTS.append(host)
        if public_url not in settings.CSRF_TRUSTED_ORIGINS:
            settings.CSRF_TRUSTED_ORIGINS.append(public_url)
        settings.WEBAUTHN_RP_ID = host
        settings.WEBAUTHN_ORIGIN = public_url

        self.stdout.write(self.style.SUCCESS(f'\nngrok tunnel is live: {public_url}\n'))
        self.stdout.write('Share that URL to reach this app from anywhere.\n')
        self.stdout.write(
            'Note: passkeys registered under localhost will not work on this new '
            'domain (WebAuthn ties a passkey to the exact domain it was registered '
            'on) — register a new one from Settings if you want passkey login here.\n'
        )

        call_command('runserver', f'0.0.0.0:{port}', use_reloader=False)
