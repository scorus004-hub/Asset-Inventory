from django.contrib import admin
from .models import (
    Rack, Device, Handover, ActivityLog, AppSettings, WebAuthnCredential,
    DeviceCategory, DeviceBrand, Manufacturer, CategoryAttribute,
)


class DeviceInline(admin.TabularInline):
    model = Device
    extra = 0


@admin.register(Rack)
class RackAdmin(admin.ModelAdmin):
    list_display = ['label', 'total_units', 'created_at']
    inlines = [DeviceInline]


@admin.register(DeviceCategory)
class DeviceCategoryAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']


@admin.register(DeviceBrand)
class DeviceBrandAdmin(admin.ModelAdmin):
    list_display = ['name', 'category']
    list_filter = ['category']
    search_fields = ['name']


@admin.register(Manufacturer)
class ManufacturerAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']


@admin.register(CategoryAttribute)
class CategoryAttributeAdmin(admin.ModelAdmin):
    list_display = ['name', 'category']
    list_filter = ['category']
    search_fields = ['name']


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    list_display = ['category', 'manufacturer', 'brand', 'serial_number', 'part_number', 'warehouse_number', 'status', 'condition', 'rack', 'added_by', 'created_at']
    list_filter = ['rack', 'category', 'manufacturer', 'status', 'condition']
    search_fields = ['serial_number', 'part_number', 'warehouse_number', 'location']


@admin.register(Handover)
class HandoverAdmin(admin.ModelAdmin):
    list_display = ['device_category', 'manufacturer_name', 'brand_name', 'serial_number', 'rack_label', 'recipient', 'date', 'batch_id']
    list_filter = ['date', 'device_category']
    search_fields = ['device_category', 'brand_name', 'manufacturer_name', 'serial_number', 'recipient', 'batch_id']


@admin.register(ActivityLog)
class ActivityLogAdmin(admin.ModelAdmin):
    list_display = ['timestamp', 'action', 'details']
    list_filter = ['action']


@admin.register(AppSettings)
class AppSettingsAdmin(admin.ModelAdmin):
    list_display = ['low_stock_threshold']


@admin.register(WebAuthnCredential)
class WebAuthnCredentialAdmin(admin.ModelAdmin):
    list_display = ['user', 'nickname', 'created_at', 'last_used_at']
    list_filter = ['user']
