from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from .models import Device, DeviceCategory, DeviceBrand, Manufacturer, CategoryAttribute

User = get_user_model()

BS_INPUT = {'class': 'form-control'}
BS_SELECT = {'class': 'form-select'}


class AdminUserCreateForm(UserCreationForm):
    """Superuser-only: create a new login account. Built on Django's own
    UserCreationForm so password validation/hashing follows the same rules
    as every other account — nothing custom or weaker here."""
    email = forms.EmailField(required=False, widget=forms.EmailInput(attrs=BS_INPUT))
    is_staff = forms.BooleanField(required=False, label='Staff (can access /admin/)', widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}))
    is_superuser = forms.BooleanField(required=False, label='Superuser (can manage other accounts)', widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}))

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'is_staff', 'is_superuser')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update(BS_INPUT)
        self.fields['password1'].widget.attrs.update(BS_INPUT)
        self.fields['password2'].widget.attrs.update(BS_INPUT)


class AdminUserEditForm(forms.ModelForm):
    """Superuser-only: edit an existing account's email/role/active flag.
    Deliberately excludes username and password — use the dedicated
    reset-password action for that."""
    class Meta:
        model = User
        fields = ('email', 'is_active', 'is_staff', 'is_superuser')
        widgets = {'email': forms.EmailInput(attrs=BS_INPUT)}


class AdminPasswordResetForm(forms.Form):
    new_password1 = forms.CharField(widget=forms.PasswordInput(attrs=BS_INPUT), label='New password', min_length=8)
    new_password2 = forms.CharField(widget=forms.PasswordInput(attrs=BS_INPUT), label='Confirm new password')

    def clean(self):
        cleaned = super().clean()
        if cleaned.get('new_password1') != cleaned.get('new_password2'):
            raise forms.ValidationError('Passwords do not match.')
        return cleaned


class RackRenameForm(forms.Form):
    label = forms.CharField(max_length=60, widget=forms.TextInput(attrs=BS_INPUT))


class DeviceAddForm(forms.Form):
    """
    Adds one or more serialized units at once, all sharing the same
    category / brand / manufacturer / status / condition / part number /
    warehouse number / location / description, but each with its own
    serial number (one per line). Each line becomes its own Device row.
    The Brand dropdown is filtered client-side (and re-fetched via
    /categories/<id>/brands/) to only the brands that belong to the
    selected Category.
    """
    category = forms.ModelChoiceField(
        queryset=DeviceCategory.objects.all(), label='Device category',
        widget=forms.Select(attrs={**BS_SELECT, 'class': BS_SELECT['class'] + ' js-category-select'}),
        empty_label='Choose a category...',
    )
    brand = forms.ModelChoiceField(
        queryset=DeviceBrand.objects.all(), required=False, label='Brand',
        widget=forms.Select(attrs={**BS_SELECT, 'class': BS_SELECT['class'] + ' js-brand-select'}),
        empty_label='Choose a brand...',
    )
    manufacturer = forms.ModelChoiceField(
        queryset=Manufacturer.objects.all(), required=False, label='Manufacturer',
        widget=forms.Select(attrs=BS_SELECT), empty_label='Choose a manufacturer...',
    )
    status = forms.ChoiceField(
        choices=Device.STATUS_CHOICES, initial=Device.STATUS_AVAILABLE,
        widget=forms.Select(attrs=BS_SELECT),
    )
    condition = forms.ChoiceField(
        choices=Device.CONDITION_CHOICES, initial=Device.NEW,
        widget=forms.Select(attrs=BS_SELECT),
    )
    part_number = forms.CharField(max_length=80, required=False, widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'Part number'}))
    warehouse_number = forms.CharField(max_length=80, required=False, widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'Warehouse number'}))
    location = forms.CharField(max_length=120, required=False, widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'Location (e.g. Shelf 3, Bin A2)'}))
    unit_name = forms.CharField(max_length=30, required=False, initial='unit', widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'Unit name (e.g. unit, pcs, bộ)'}))
    unit_price = forms.DecimalField(max_digits=12, decimal_places=2, required=False, widget=forms.NumberInput(attrs={**BS_INPUT, 'placeholder': 'Unit price', 'step': '0.01'}))
    contract_code = forms.CharField(max_length=60, required=False, widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'Contract code'}))
    station_code = forms.CharField(max_length=60, required=False, widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'Station code'}))
    description = forms.CharField(required=False, widget=forms.Textarea(attrs={**BS_INPUT, 'rows': 2, 'placeholder': 'Description (optional)'}))
    serial_numbers = forms.CharField(
        label='Serial number(s)', widget=forms.Textarea(attrs={
            **BS_INPUT, 'rows': 2, 'placeholder': 'One serial number per line (or comma-separated) for each unit',
        }),
    )

    def clean_serial_numbers(self):
        raw = self.cleaned_data['serial_numbers']
        serials = [s.strip() for chunk in raw.splitlines() for s in chunk.split(',')]
        serials = [s for s in serials if s]
        if not serials:
            raise forms.ValidationError('Enter at least one serial number.')
        return serials

    def clean(self):
        cleaned = super().clean()
        category = cleaned.get('category')
        brand = cleaned.get('brand')
        if category and brand and brand.category_id != category.id:
            self.add_error('brand', f'"{brand.name}" does not belong to the "{category.name}" category.')
        return cleaned


class HandoverForm(forms.Form):
    devices = forms.ModelMultipleChoiceField(
        queryset=Device.objects.select_related('rack', 'category', 'brand').all(),
        label='Devices to hand over',
        widget=forms.SelectMultiple(attrs={**BS_SELECT, 'size': 8}),
    )

    recipient = forms.CharField(max_length=80, label='Receiver name', widget=forms.TextInput(attrs=BS_INPUT))
    receiver_company = forms.CharField(max_length=120, label='Receiver company', required=False, widget=forms.TextInput(attrs=BS_INPUT))
    receiver_position = forms.CharField(max_length=80, label='Receiver position', required=False, widget=forms.TextInput(attrs=BS_INPUT))
    receiver_phone = forms.CharField(max_length=40, label='Receiver phone number', required=False, widget=forms.TextInput(attrs=BS_INPUT))

    sender_name = forms.CharField(max_length=80, label='Delivered by (name)', required=False, widget=forms.TextInput(attrs=BS_INPUT))
    sender_position = forms.CharField(max_length=80, label='Delivered by (position)', required=False, widget=forms.TextInput(attrs=BS_INPUT))
    sender_phone = forms.CharField(max_length=40, label='Delivered by (phone)', required=False, widget=forms.TextInput(attrs=BS_INPUT))

    transportation_name = forms.CharField(max_length=80, label='Transported by (name, optional)', required=False, widget=forms.TextInput(attrs=BS_INPUT))
    location = forms.CharField(
        max_length=200, label='Handover location', required=False,
        widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'e.g. Warehouse in Bebonuk, Dili, Timor-Leste'}),
    )

    equipment_status = forms.CharField(
        max_length=150, label='Equipment status', required=False,
        widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'e.g. Hand over old server, Broken — needs repair'}),
    )
    date = forms.DateField(widget=forms.DateInput(attrs={**BS_INPUT, 'type': 'date'}))
    notes = forms.CharField(widget=forms.Textarea(attrs=BS_INPUT), required=False, max_length=300)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['devices'].queryset = Device.objects.select_related('rack', 'category', 'brand').order_by('category__name', 'serial_number')
        self.fields['devices'].label_from_instance = (
            lambda d: f'{d.category.name}{" — " + d.brand.name if d.brand else ""} — SN:{d.serial_number} — {d.rack.label}'
        )


class CompanyInfoForm(forms.Form):
    company_name = forms.CharField(max_length=150, required=False, widget=forms.TextInput(attrs=BS_INPUT))
    warehouse_address = forms.CharField(max_length=255, required=False, widget=forms.TextInput(attrs=BS_INPUT))


class ThresholdForm(forms.Form):
    low_stock_threshold = forms.IntegerField(
        min_value=1, label='Alert when qty is below',
        widget=forms.NumberInput(attrs={**BS_INPUT, 'style': 'width:100px;'}),
    )


class PasskeyNicknameForm(forms.Form):
    nickname = forms.CharField(
        max_length=60, required=False, label='Name this passkey (optional)',
        widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'e.g. Work laptop'}),
    )


class ImportFileForm(forms.Form):
    backup_file = forms.FileField(widget=forms.ClearableFileInput(attrs={'class': 'form-control'}))


# ---------- "Add a new option" popup forms (used via AJAX from Racks page) ----------

class DeviceCategoryQuickAddForm(forms.Form):
    name = forms.CharField(max_length=60, widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'e.g. Network Card'}))

    def clean_name(self):
        name = self.cleaned_data['name'].strip()
        if DeviceCategory.objects.filter(name__iexact=name).exists():
            raise forms.ValidationError('That category already exists.')
        return name


class DeviceBrandQuickAddForm(forms.Form):
    category = forms.ModelChoiceField(queryset=DeviceCategory.objects.all(), widget=forms.Select(attrs=BS_SELECT))
    name = forms.CharField(max_length=150, widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'e.g. Dell PowerVault MD3600i Dual Ports'}))

    def clean(self):
        cleaned = super().clean()
        category = cleaned.get('category')
        name = (cleaned.get('name') or '').strip()
        if category and name and DeviceBrand.objects.filter(category=category, name__iexact=name).exists():
            raise forms.ValidationError('That brand already exists for this category.')
        cleaned['name'] = name
        return cleaned


class ManufacturerQuickAddForm(forms.Form):
    name = forms.CharField(max_length=80, widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'e.g. Dell'}))

    def clean_name(self):
        name = self.cleaned_data['name'].strip()
        if Manufacturer.objects.filter(name__iexact=name).exists():
            raise forms.ValidationError('That manufacturer already exists.')
        return name


class CategoryAttributeQuickAddForm(forms.Form):
    """Adds a custom detail field (e.g. Capacity, Speed) scoped to one
    category — SSD might have Type/Capacity/Speed/Size, Power Supply might
    just have Capacity."""
    category = forms.ModelChoiceField(queryset=DeviceCategory.objects.all(), widget=forms.Select(attrs=BS_SELECT))
    name = forms.CharField(max_length=60, widget=forms.TextInput(attrs={**BS_INPUT, 'placeholder': 'e.g. Capacity'}))

    def clean(self):
        cleaned = super().clean()
        category = cleaned.get('category')
        name = (cleaned.get('name') or '').strip()
        if category and name and CategoryAttribute.objects.filter(category=category, name__iexact=name).exists():
            raise forms.ValidationError('That detail field already exists for this category.')
        cleaned['name'] = name
        return cleaned


class CategoryAttributeRenameForm(forms.Form):
    name = forms.CharField(max_length=60, widget=forms.TextInput(attrs=BS_INPUT))

    def clean_name(self):
        return self.cleaned_data['name'].strip()
