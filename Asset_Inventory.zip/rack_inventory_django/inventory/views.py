import csv
import json
from datetime import date

from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.core.paginator import Paginator
from django.db.models import Q, Count
from django.db.models.functions import TruncMonth
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect, get_object_or_404, get_list_or_404
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST, require_GET

import webauthn
from webauthn.helpers import base64url_to_bytes, bytes_to_base64url
from webauthn.helpers.structs import (
    AuthenticatorSelectionCriteria,
    ResidentKeyRequirement,
    UserVerificationRequirement,
    PublicKeyCredentialDescriptor,
)

from django.conf import settings as django_settings
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password

from .forms import (
    RackRenameForm, DeviceAddForm, HandoverForm, ThresholdForm,
    ImportFileForm, PasskeyNicknameForm, DeviceCategoryQuickAddForm,
    DeviceBrandQuickAddForm, ManufacturerQuickAddForm,
    CategoryAttributeQuickAddForm, CategoryAttributeRenameForm,
    AdminUserCreateForm, AdminUserEditForm, AdminPasswordResetForm,
    CompanyInfoForm,
)
from .models import (
    Rack, Device, Handover, ActivityLog, AppSettings, WebAuthnCredential,
    DeviceCategory, DeviceBrand, Manufacturer, CategoryAttribute,
)
from .local_ai import answer_query
from .qr import qr_png_response
from .handover_doc import build_handover_docx

User = get_user_model()


# ---------- Auth ----------

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            ActivityLog.log('Security', f'{form.get_user().username} logged in (password)')
            next_url = request.GET.get('next') or reverse('dashboard')
            return redirect(next_url)
    else:
        form = AuthenticationForm(request)

    return render(request, 'inventory/login.html', {'form': form})


def logout_view(request):
    if request.user.is_authenticated:
        ActivityLog.log('Security', f'{request.user.username} logged out')
    logout(request)
    return redirect('login')

# ---------- WebAuthn: registering a passkey (must be logged in already) ----------

@require_POST
def webauthn_register_begin(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Login required'}, status=401)

    existing = [
        PublicKeyCredentialDescriptor(id=base64url_to_bytes(c.credential_id))
        for c in request.user.webauthn_credentials.all()
    ]

    options = webauthn.generate_registration_options(
        rp_id=django_settings.WEBAUTHN_RP_ID,
        rp_name=django_settings.WEBAUTHN_RP_NAME,
        user_id=str(request.user.id).encode('utf-8'),
        user_name=request.user.username,
        user_display_name=request.user.get_full_name() or request.user.username,
        authenticator_selection=AuthenticatorSelectionCriteria(
            resident_key=ResidentKeyRequirement.PREFERRED,
            user_verification=UserVerificationRequirement.PREFERRED,
        ),
        exclude_credentials=existing,
    )
    request.session['webauthn_register_challenge'] = bytes_to_base64url(options.challenge)
    return HttpResponse(webauthn.options_to_json(options), content_type='application/json')


@require_POST
def webauthn_register_complete(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Login required'}, status=401)

    challenge_b64 = request.session.get('webauthn_register_challenge')
    if not challenge_b64:
        return JsonResponse({'error': 'No registration in progress.'}, status=400)

    try:
        credential = webauthn.helpers.parse_registration_credential_json(request.body)
        verification = webauthn.verify_registration_response(
            credential=credential,
            expected_challenge=base64url_to_bytes(challenge_b64),
            expected_origin=django_settings.WEBAUTHN_ORIGIN,
            expected_rp_id=django_settings.WEBAUTHN_RP_ID,
        )
    except Exception as exc:
        return JsonResponse({'error': f'Could not verify passkey: {exc}'}, status=400)

    nickname = ''
    try:
        body = json.loads(request.body)
        nickname = (body.get('nickname') or '')[:60]
    except Exception:
        pass

    WebAuthnCredential.objects.create(
        user=request.user,
        nickname=nickname,
        credential_id=bytes_to_base64url(verification.credential_id),
        public_key=bytes_to_base64url(verification.credential_public_key),
        sign_count=verification.sign_count,
    )
    del request.session['webauthn_register_challenge']
    ActivityLog.log('Security', f'Passkey registered for {request.user.username}' + (f' ({nickname})' if nickname else ''))
    return JsonResponse({'ok': True})


@require_POST
def webauthn_credential_delete(request, cred_id):
    cred = get_object_or_404(WebAuthnCredential, id=cred_id, user=request.user)
    label = cred.nickname or cred.credential_id[:12]
    cred.delete()
    ActivityLog.log('Security', f'Passkey removed for {request.user.username} ({label})')
    messages.success(request, 'Passkey removed.')
    return redirect('settings')


# ---------- WebAuthn: passwordless login (no session yet) ----------

@require_POST
def webauthn_login_begin(request):
    options = webauthn.generate_authentication_options(
        rp_id=django_settings.WEBAUTHN_RP_ID,
        user_verification=UserVerificationRequirement.PREFERRED,
    )
    request.session['webauthn_login_challenge'] = bytes_to_base64url(options.challenge)
    return HttpResponse(webauthn.options_to_json(options), content_type='application/json')


@require_POST
def webauthn_login_complete(request):
    challenge_b64 = request.session.get('webauthn_login_challenge')
    if not challenge_b64:
        return JsonResponse({'error': 'No login attempt in progress.'}, status=400)

    try:
        credential = webauthn.helpers.parse_authentication_credential_json(request.body)
    except Exception as exc:
        return JsonResponse({'error': f'Malformed passkey response: {exc}'}, status=400)

    credential_id_b64 = bytes_to_base64url(credential.raw_id)
    stored = WebAuthnCredential.objects.filter(credential_id=credential_id_b64).select_related('user').first()
    if not stored:
        return JsonResponse({'error': 'That passkey is not registered here.'}, status=400)

    try:
        verification = webauthn.verify_authentication_response(
            credential=credential,
            expected_challenge=base64url_to_bytes(challenge_b64),
            expected_origin=django_settings.WEBAUTHN_ORIGIN,
            expected_rp_id=django_settings.WEBAUTHN_RP_ID,
            credential_public_key=base64url_to_bytes(stored.public_key),
            credential_current_sign_count=stored.sign_count,
        )
    except Exception as exc:
        return JsonResponse({'error': f'Could not verify passkey: {exc}'}, status=400)

    stored.sign_count = verification.new_sign_count
    stored.last_used_at = timezone.now()
    stored.save()

    user = stored.user
    user.backend = 'django.contrib.auth.backends.ModelBackend'
    login(request, user)
    del request.session['webauthn_login_challenge']
    ActivityLog.log('Security', f'{user.username} logged in (passkey)')
    return JsonResponse({'ok': True, 'redirect': reverse('dashboard')})


# ---------- Dashboard ----------

def dashboard_view(request):
    racks = Rack.objects.prefetch_related('devices').all()
    settings_obj = AppSettings.load()

    all_devices = [d for r in racks for d in r.devices.all()]
    total_units = len(all_devices)
    unique_categories = {d.category_id for d in all_devices}

    grouped = {}
    for d in all_devices:
        key = d.category_id
        entry = grouped.setdefault(key, {'name': d.category.name, 'total': 0, 'locations': {}})
        entry['total'] += 1
        entry['locations'][d.rack.label] = entry['locations'].get(d.rack.label, 0) + 1
    device_rows = sorted(grouped.values(), key=lambda x: -x['total'])

    # A "low stock" row is a (category, rack) group whose count is below
    # the threshold — matches the grouping shown on the Racks page.
    low_stock_count = 0
    for r in racks:
        for group in r.grouped_devices():
            if group['count'] < settings_obj.low_stock_threshold:
                low_stock_count += 1

    recent_handovers = Handover.objects.all()[:5]

    rack_dist = [{'label': r.label, 'total': r.total_units()} for r in racks if r.total_units() > 0]
    top_devices = sorted(device_rows, key=lambda x: -x['total'])[:6]

    status_counts, condition_counts, manufacturer_counts = {}, {}, {}
    for d in all_devices:
        status_counts[d.get_status_display()] = status_counts.get(d.get_status_display(), 0) + 1
        condition_counts[d.get_condition_display()] = condition_counts.get(d.get_condition_display(), 0) + 1
        mname = d.manufacturer.name if d.manufacturer else 'Unspecified'
        manufacturer_counts[mname] = manufacturer_counts.get(mname, 0) + 1
    top_manufacturers = sorted(manufacturer_counts.items(), key=lambda x: -x[1])[:6]

    monthly = (
        Handover.objects.annotate(month=TruncMonth('date'))
        .values('month').annotate(qty=Count('id')).order_by('month')
    )
    monthly_list = list(monthly)

    chart_data = {
        'rack_labels': [r['label'] for r in rack_dist],
        'rack_units': [r['total'] for r in rack_dist],
        'top_device_labels': [d['name'] for d in top_devices],
        'top_device_units': [d['total'] for d in top_devices],
        'month_labels': [m['month'].strftime('%Y-%m') for m in monthly_list],
        'month_units': [m['qty'] for m in monthly_list],
        'status_labels': list(status_counts.keys()),
        'status_units': list(status_counts.values()),
        'condition_labels': list(condition_counts.keys()),
        'condition_units': list(condition_counts.values()),
        'manufacturer_labels': [m[0] for m in top_manufacturers],
        'manufacturer_units': [m[1] for m in top_manufacturers],
    }

    context = {
        'rack_count': racks.count(),
        'unique_count': len(unique_categories),
        'total_units': total_units,
        'low_stock_count': low_stock_count,
        'handover_count': Handover.objects.count(),
        'device_rows': device_rows,
        'recent_handovers': recent_handovers,
        'chart_data_json': json.dumps(chart_data),
    }
    return render(request, 'inventory/dashboard.html', context)


# ---------- Racks ----------

def racks_view(request):
    DeviceCategory.ensure_defaults()
    Manufacturer.ensure_defaults()
    racks = Rack.objects.prefetch_related('devices').all()
    threshold = AppSettings.load().low_stock_threshold
    device_form = DeviceAddForm()
    rename_form = RackRenameForm()
    return render(request, 'inventory/racks.html', {
        'racks': racks, 'threshold': threshold, 'device_form': device_form, 'rename_form': rename_form,
        'categories': DeviceCategory.objects.all(), 'manufacturers': Manufacturer.objects.all(),
        'status_choices': Device.STATUS_CHOICES, 'condition_choices': Device.CONDITION_CHOICES,
    })


@require_POST
def rack_add(request):
    count = Rack.objects.count() + 1
    label = f'Rack {count:02d}'
    while Rack.objects.filter(label=label).exists():
        count += 1
        label = f'Rack {count:02d}'
    Rack.objects.create(label=label)
    ActivityLog.log('Rack added', label)
    messages.success(request, f'{label} added.')
    return redirect('racks')


@require_POST
def rack_rename(request, rack_id):
    rack = get_object_or_404(Rack, id=rack_id)
    form = RackRenameForm(request.POST)
    if form.is_valid():
        old_label = rack.label
        rack.label = form.cleaned_data['label'].strip() or rack.label
        rack.save()
        ActivityLog.log('Rack renamed', f'{old_label} -> {rack.label}')
    return redirect('racks')


@require_POST
def rack_delete(request, rack_id):
    rack = get_object_or_404(Rack, id=rack_id)
    label = rack.label
    rack.delete()
    ActivityLog.log('Rack deleted', label)
    messages.success(request, f'{label} deleted.')
    return redirect('racks')


@require_POST
def device_add(request, rack_id):
    rack = get_object_or_404(Rack, id=rack_id)
    form = DeviceAddForm(request.POST)
    if not form.is_valid():
        for field, errs in form.errors.items():
            for err in errs:
                messages.error(request, err)
        return redirect('racks')

    category = form.cleaned_data['category']
    brand = form.cleaned_data['brand']
    manufacturer = form.cleaned_data['manufacturer']
    part_number = form.cleaned_data['part_number']
    warehouse_number = form.cleaned_data['warehouse_number']
    status = form.cleaned_data['status']
    condition = form.cleaned_data['condition']
    location = form.cleaned_data['location']
    description = form.cleaned_data['description']
    unit_name = form.cleaned_data['unit_name']
    unit_price = form.cleaned_data['unit_price']
    contract_code = form.cleaned_data['contract_code']
    station_code = form.cleaned_data['station_code']
    serials = form.cleaned_data['serial_numbers']

    # Category-specific detail fields (e.g. Capacity/Speed/Type for SSD)
    # are rendered dynamically in the template based on the chosen
    # category, named attr_<CategoryAttribute.id> — collect whichever of
    # those were submitted for this category.
    attr_defs = CategoryAttribute.objects.filter(category=category)
    attributes = {}
    for attr in attr_defs:
        value = request.POST.get(f'attr_{attr.id}', '').strip()
        if value:
            attributes[attr.name] = value

    added, failed = [], []
    for serial in serials:
        try:
            rack.add_device_unit(
                category=category, brand=brand, manufacturer=manufacturer,
                part_number=part_number, serial_number=serial, warehouse_number=warehouse_number,
                status=status, condition=condition, location=location, description=description,
                added_by=request.user, attributes=attributes,
                unit_name=unit_name, unit_price=unit_price,
                contract_code=contract_code, station_code=station_code,
            )
            added.append(serial)
        except ValueError as exc:
            failed.append(str(exc))

    if added:
        ActivityLog.log('Device added', f'{category.name} x{len(added)} in {rack.label} (SN: {", ".join(added)})')
        messages.success(request, f'Added {len(added)} unit(s) of "{category.name}" to {rack.label}.')
    for msg in failed:
        messages.error(request, msg)
    return redirect('racks')


@require_POST
def device_delete(request, device_id):
    device = get_object_or_404(Device, id=device_id)
    name, rack_label = device.category.name, device.rack.label
    device.delete()
    ActivityLog.log('Device removed', f'{name} from {rack_label}')
    messages.success(request, f'{name} removed.')
    return redirect('racks')


def rack_detail_view(request, rack_id):
    rack = get_object_or_404(Rack.objects.prefetch_related('devices'), id=rack_id)
    threshold = AppSettings.load().low_stock_threshold
    return render(request, 'inventory/rack_detail.html', {'rack': rack, 'threshold': threshold})


def device_detail_view(request, device_id):
    device = get_object_or_404(Device.objects.select_related('rack', 'category', 'brand', 'manufacturer'), id=device_id)
    threshold = AppSettings.load().low_stock_threshold
    history = Handover.objects.filter(device_category__iexact=device.category.name, serial_number=device.serial_number).order_by('-date')
    same_category_total = Device.objects.filter(category=device.category).count()
    return render(request, 'inventory/device_detail.html', {
        'device': device, 'threshold': threshold, 'history': history,
        'same_category_total': same_category_total,
    })


def device_qr(request, device_id):
    device = get_object_or_404(Device, id=device_id)
    url = request.build_absolute_uri(reverse('device_detail', args=[device.id]))
    return qr_png_response(url)


def scan_view(request):
    return render(request, 'inventory/scan.html')


# ---------- Racks: quick-add popups for Category / Brand / Manufacturer ----------

@require_POST
def category_quick_add(request):
    form = DeviceCategoryQuickAddForm(request.POST)
    if not form.is_valid():
        return JsonResponse({'error': next(iter(form.errors.get('name', ['Invalid name.'])))}, status=400)
    category = DeviceCategory.objects.create(name=form.cleaned_data['name'])
    ActivityLog.log('Category added', category.name)
    return JsonResponse({'id': category.id, 'name': category.name})


@require_POST
def brand_quick_add(request):
    form = DeviceBrandQuickAddForm(request.POST)
    if not form.is_valid():
        first_error = next(iter(form.errors.values()))[0] if form.errors else 'Invalid brand.'
        return JsonResponse({'error': first_error}, status=400)
    brand = DeviceBrand.objects.create(category=form.cleaned_data['category'], name=form.cleaned_data['name'])
    ActivityLog.log('Brand added', f'{brand.name} ({brand.category.name})')
    return JsonResponse({'id': brand.id, 'name': brand.name, 'category_id': brand.category_id})


@require_POST
def manufacturer_quick_add(request):
    form = ManufacturerQuickAddForm(request.POST)
    if not form.is_valid():
        return JsonResponse({'error': next(iter(form.errors.get('name', ['Invalid name.'])))}, status=400)
    manufacturer = Manufacturer.objects.create(name=form.cleaned_data['name'])
    ActivityLog.log('Manufacturer added', manufacturer.name)
    return JsonResponse({'id': manufacturer.id, 'name': manufacturer.name})


@require_GET
def brands_for_category(request, category_id):
    brands = DeviceBrand.objects.filter(category_id=category_id).values('id', 'name')
    return JsonResponse({'brands': list(brands)})


# ---------- Racks: per-category custom detail fields (e.g. Capacity, Speed) ----------
# Each Device Category can define its own extra detail fields — SSD might
# have Type/Capacity/Speed/Size, Power Supply might just have Capacity.
# These are user-managed (add/rename/delete) right from the Add Device
# popup, same "+" pattern as Brand and Manufacturer.

@require_GET
def attributes_for_category(request, category_id):
    attrs = CategoryAttribute.objects.filter(category_id=category_id).values('id', 'name')
    return JsonResponse({'attributes': list(attrs)})


@require_POST
def category_attribute_quick_add(request):
    form = CategoryAttributeQuickAddForm(request.POST)
    if not form.is_valid():
        first_error = next(iter(form.errors.values()))[0] if form.errors else 'Invalid detail field.'
        return JsonResponse({'error': first_error}, status=400)
    attr = CategoryAttribute.objects.create(category=form.cleaned_data['category'], name=form.cleaned_data['name'])
    ActivityLog.log('Detail field added', f'{attr.name} ({attr.category.name})')
    return JsonResponse({'id': attr.id, 'name': attr.name, 'category_id': attr.category_id})


@require_POST
def category_attribute_rename(request, attr_id):
    attr = get_object_or_404(CategoryAttribute, id=attr_id)
    form = CategoryAttributeRenameForm(request.POST)
    if not form.is_valid():
        return JsonResponse({'error': 'Enter a valid name.'}, status=400)
    old_name = attr.name
    attr.name = form.cleaned_data['name']
    attr.save()
    ActivityLog.log('Detail field renamed', f'{old_name} -> {attr.name} ({attr.category.name})')
    return JsonResponse({'id': attr.id, 'name': attr.name})


@require_POST
def category_attribute_delete(request, attr_id):
    attr = get_object_or_404(CategoryAttribute, id=attr_id)
    name, category_name = attr.name, attr.category.name
    attr.delete()
    ActivityLog.log('Detail field removed', f'{name} ({category_name})')
    return JsonResponse({'deleted': True})


# ---------- Handover ----------

def _handover_picker_groups():
    """Group available (in-stock) devices by CATEGORY for the handover
    picker — shows the total count of that category (e.g. all SSDs
    together regardless of brand/manufacturer), with each individual
    unit's brand/manufacturer/part/serial/warehouse detail underneath."""
    groups = {}
    order = []
    for d in Device.objects.select_related('rack', 'category', 'brand', 'manufacturer').order_by('category__name', 'rack__created_at', 'serial_number'):
        key = d.category_id
        if key not in groups:
            groups[key] = {'category': d.category, 'units': []}
            order.append(key)
        groups[key]['units'].append(d)
    result = []
    for key in order:
        g = groups[key]
        g['total'] = len(g['units'])
        result.append(g)
    return result


def handover_view(request):
    if request.method == 'POST':
        form = HandoverForm(request.POST)
        if form.is_valid():
            devices = list(form.cleaned_data['devices'])
            recipient = form.cleaned_data['recipient']
            ho_date = form.cleaned_data['date']
            notes = form.cleaned_data['notes']
            receiver_company = form.cleaned_data['receiver_company']
            receiver_position = form.cleaned_data['receiver_position']
            receiver_phone = form.cleaned_data['receiver_phone']
            sender_name = form.cleaned_data['sender_name']
            sender_position = form.cleaned_data['sender_position']
            sender_phone = form.cleaned_data['sender_phone']
            equipment_status = form.cleaned_data['equipment_status']
            transportation_name = form.cleaned_data['transportation_name']
            location = form.cleaned_data['location']

            batch_id = timezone.now().strftime('%Y%m%d%H%M%S%f')
            for device in devices:
                Handover.objects.create(
                    device_category=device.category.name,
                    brand_name=device.brand.name if device.brand else '',
                    manufacturer_name=device.manufacturer.name if device.manufacturer else '',
                    part_number=device.part_number, serial_number=device.serial_number,
                    warehouse_number=device.warehouse_number, condition=device.condition,
                    attributes=device.attributes, rack_label=device.rack.label,
                    unit_name=device.unit_name, unit_price=device.unit_price,
                    contract_code=device.contract_code, station_code=device.station_code,
                    recipient=recipient, receiver_company=receiver_company,
                    receiver_position=receiver_position, receiver_phone=receiver_phone,
                    sender_name=sender_name, sender_position=sender_position, sender_phone=sender_phone,
                    transportation_name=transportation_name, location=location,
                    equipment_status=equipment_status, date=ho_date, notes=notes,
                    handed_over_by=request.user, batch_id=batch_id,
                )
                device.delete()

            names = ', '.join(sorted({d.category.name for d in devices}))
            ActivityLog.log('Handover submitted', f'{len(devices)} unit(s) ({names}) to {recipient}')
            messages.success(
                request,
                f'{len(devices)} unit(s) handed over to {recipient}. '
                f'<a href="{reverse("handover_docx", args=[batch_id])}" class="alert-link">Download the signable Word document</a>.',
                extra_tags='safe',
            )
            return redirect('handover')
    else:
        display_name = request.user.get_full_name() or request.user.username
        settings_obj = AppSettings.load()
        form = HandoverForm(initial={
            'date': date.today(), 'sender_name': display_name,
            'location': settings_obj.warehouse_address,
        })

    history_qs = Handover.objects.all()
    paginator = Paginator(history_qs, 20)
    page_number = request.GET.get('page')
    history = paginator.get_page(page_number)
    return render(request, 'inventory/handover.html', {
        'form': form, 'history': history, 'picker_groups': _handover_picker_groups(),
    })


def handover_print(request, batch_id):
    items = get_list_or_404(Handover, batch_id=batch_id)
    return render(request, 'inventory/handover_print.html', {'items': items, 'batch_id': batch_id})


def handover_docx(request, batch_id):
    items = get_list_or_404(Handover, batch_id=batch_id)
    settings_obj = AppSettings.load()
    docx_bytes = build_handover_docx(
        items, company_name=settings_obj.company_name, warehouse_address=settings_obj.warehouse_address,
    )
    response = HttpResponse(
        docx_bytes,
        content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    )
    response['Content-Disposition'] = f'attachment; filename="handover-{items[0].date}-{batch_id[:8]}.docx"'
    return response


# ---------- Search ----------

def search_view(request):
    q = request.GET.get('q', '').strip()
    devices = Device.objects.select_related('rack', 'category', 'brand', 'manufacturer').all()
    handovers = Handover.objects.all()
    if q:
        devices = devices.filter(
            Q(category__name__icontains=q) | Q(brand__name__icontains=q) | Q(manufacturer__name__icontains=q) |
            Q(rack__label__icontains=q) | Q(serial_number__icontains=q) | Q(part_number__icontains=q) |
            Q(warehouse_number__icontains=q) | Q(location__icontains=q)
        )
        handovers = handovers.filter(
            Q(device_category__icontains=q) | Q(brand_name__icontains=q) | Q(manufacturer_name__icontains=q) |
            Q(recipient__icontains=q) | Q(rack_label__icontains=q) |
            Q(serial_number__icontains=q) | Q(part_number__icontains=q)
        )
    return render(request, 'inventory/search.html', {
        'q': q, 'devices': devices, 'handovers': handovers,
    })


# ---------- Reports ----------

def _low_stock_rows(threshold):
    """Low stock is evaluated per (category, rack) group — matching the
    grouping shown on the Racks page — since quantity is a count of
    serialized units rather than a stored number."""
    rows = []
    for rack in Rack.objects.prefetch_related('devices').all():
        for group in rack.grouped_devices():
            if group['count'] < threshold:
                rows.append({'category': group['category'].name, 'rack_label': rack.label, 'count': group['count']})
    rows.sort(key=lambda r: r['count'])
    return rows


def reports_view(request):
    settings_obj = AppSettings.load()
    if request.method == 'POST':
        form = ThresholdForm(request.POST)
        if form.is_valid():
            settings_obj.low_stock_threshold = form.cleaned_data['low_stock_threshold']
            settings_obj.save()
            ActivityLog.log('Settings changed', f'Low stock threshold set to {settings_obj.low_stock_threshold}')
            messages.success(request, 'Threshold saved.')
            return redirect('reports')
    else:
        form = ThresholdForm(initial={'low_stock_threshold': settings_obj.low_stock_threshold})

    low_stock = _low_stock_rows(settings_obj.low_stock_threshold)

    top_devices = (
        Handover.objects.values('device_category')
        .annotate(total_qty=Count('id'))
        .order_by('-total_qty')[:8]
    )
    max_qty = max([d['total_qty'] for d in top_devices], default=1)
    for d in top_devices:
        d['pct'] = round((d['total_qty'] / max_qty) * 100) if max_qty else 0

    monthly = (
        Handover.objects.annotate(month=TruncMonth('date'))
        .values('month')
        .annotate(qty=Count('id'))
        .order_by('month')
    )
    monthly_list = list(monthly)

    rack_totals = [
        {'label': r.label, 'total': r.total_units()}
        for r in Rack.objects.prefetch_related('devices').all()
    ]

    chart_data = {
        'rack_labels': [r['label'] for r in rack_totals],
        'rack_units': [r['total'] for r in rack_totals],
        'month_labels': [m['month'].strftime('%Y-%m') for m in monthly_list],
        'month_units': [m['qty'] for m in monthly_list],
    }

    all_racks = Rack.objects.prefetch_related('devices').all()
    rack_summary = []
    for r in all_racks:
        groups = r.grouped_devices()
        low_count = sum(1 for g in groups if g['count'] < settings_obj.low_stock_threshold)
        rack_summary.append({
            'id': r.id, 'label': r.label, 'total': r.total_units(),
            'categories': len(groups), 'low_stock': low_count,
        })

    return render(request, 'inventory/reports.html', {
        'form': form, 'low_stock': low_stock, 'top_devices': top_devices,
        'monthly': list(reversed(monthly_list)), 'chart_data_json': json.dumps(chart_data),
        'racks': all_racks, 'rack_summary': rack_summary,
        'total_units': sum(r['total'] for r in rack_totals),
        'total_handovers': Handover.objects.count(),
    })


@require_POST
def reports_export(request):
    rack_ids = request.POST.getlist('rack_ids')
    fmt = request.POST.get('format', 'csv')
    if not rack_ids:
        messages.error(request, 'Select at least one rack to export.')
        return redirect('reports')

    racks = Rack.objects.filter(id__in=rack_ids).prefetch_related('devices')
    rack_labels = ', '.join(r.label for r in racks)

    if fmt == 'json':
        payload = {
            'racks': [
                {
                    'label': r.label,
                    'devices': [
                        {
                            'category': d.category.name,
                            'manufacturer': d.manufacturer.name if d.manufacturer else None,
                            'brand': d.brand.name if d.brand else None,
                            'part_number': d.part_number, 'serial_number': d.serial_number,
                            'warehouse_number': d.warehouse_number, 'status': d.status,
                            'condition': d.condition, 'location': d.location,
                            'description': d.description, 'attributes': d.attributes,
                        }
                        for d in r.devices.all()
                    ],
                }
                for r in racks
            ],
            'exported_at': date.today().isoformat(),
        }
        response = HttpResponse(json.dumps(payload, indent=2), content_type='application/json')
        response['Content-Disposition'] = f'attachment; filename="racks-export-{date.today().isoformat()}.json"'
    else:
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename="racks-export-{date.today().isoformat()}.csv"'
        writer = csv.writer(response)
        writer.writerow(['Rack', 'Category', 'Manufacturer', 'Brand', 'Part Number', 'Serial Number',
                          'Warehouse Number', 'Status', 'Condition', 'Location', 'Description'])
        for r in racks:
            for d in r.devices.all():
                writer.writerow([
                    r.label, d.category.name, d.manufacturer.name if d.manufacturer else '',
                    d.brand.name if d.brand else '', d.part_number, d.serial_number,
                    d.warehouse_number, d.get_status_display(), d.get_condition_display(),
                    d.location, d.description,
                ])

    ActivityLog.log('Export', f'Exported {len(rack_ids)} rack(s) as {fmt.upper()}: {rack_labels}')
    return response


# ---------- Activity log ----------

def activity_view(request):
    logs_qs = ActivityLog.objects.all()
    paginator = Paginator(logs_qs, 30)
    page_number = request.GET.get('page')
    logs = paginator.get_page(page_number)
    total = logs_qs.count()
    return render(request, 'inventory/activity.html', {'logs': logs, 'total': total})


# ---------- Settings ----------

def settings_view(request):
    import_form = ImportFileForm()
    passkey_form = PasskeyNicknameForm()
    passkeys = request.user.webauthn_credentials.all()
    settings_obj = AppSettings.load()
    company_form = CompanyInfoForm(initial={
        'company_name': settings_obj.company_name,
        'warehouse_address': settings_obj.warehouse_address,
    })
    return render(request, 'inventory/settings.html', {
        'import_form': import_form,
        'passkey_form': passkey_form,
        'passkeys': passkeys,
        'company_form': company_form,
        'webauthn_rp_id': django_settings.WEBAUTHN_RP_ID,
        'categories': DeviceCategory.objects.all(),
        'brands': DeviceBrand.objects.select_related('category').all(),
        'manufacturers': Manufacturer.objects.all(),
    })


@require_POST
def settings_company_save(request):
    guard = _superuser_required(request)
    if guard:
        return guard
    form = CompanyInfoForm(request.POST)
    if form.is_valid():
        settings_obj = AppSettings.load()
        settings_obj.company_name = form.cleaned_data['company_name']
        settings_obj.warehouse_address = form.cleaned_data['warehouse_address']
        settings_obj.save()
        ActivityLog.log('Settings changed', 'Company info updated')
        messages.success(request, 'Company info saved.')
    else:
        for field, errs in form.errors.items():
            for err in errs:
                messages.error(request, err)
    return redirect('settings')


@require_POST
def settings_export_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="rack-inventory-{date.today().isoformat()}.csv"'
    writer = csv.writer(response)
    writer.writerow(['Type', 'Category', 'Manufacturer', 'Brand', 'PartNumber', 'SerialNumber', 'WarehouseNumber', 'Status', 'Condition', 'Location', 'Rack', 'Recipient', 'Date', 'Notes'])
    for d in Device.objects.select_related('rack', 'category', 'brand', 'manufacturer').all():
        writer.writerow([
            'Device', d.category.name, d.manufacturer.name if d.manufacturer else '', d.brand.name if d.brand else '',
            d.part_number, d.serial_number, d.warehouse_number, d.get_status_display(), d.get_condition_display(),
            d.location, d.rack.label, '', '', '',
        ])
    for h in Handover.objects.all():
        writer.writerow([
            'Handover', h.device_category, h.manufacturer_name, h.brand_name, h.part_number, h.serial_number,
            h.warehouse_number, '', h.get_condition_display(), '', h.rack_label, h.recipient, h.date, h.notes,
        ])
    ActivityLog.log('Backup', 'CSV exported')
    return response


@require_POST
def settings_export(request):
    racks = list(Rack.objects.prefetch_related('devices').all())
    payload = {
        'racks': [
            {
                'label': r.label,
                'devices': [
                    {
                        'category': d.category.name, 'manufacturer': d.manufacturer.name if d.manufacturer else '',
                        'brand': d.brand.name if d.brand else '', 'part_number': d.part_number,
                        'serial_number': d.serial_number, 'warehouse_number': d.warehouse_number,
                        'status': d.status, 'condition': d.condition, 'location': d.location,
                        'description': d.description,
                    }
                    for d in r.devices.all()
                ],
            }
            for r in racks
        ],
        'handovers': [
            {
                'device_category': h.device_category, 'manufacturer_name': h.manufacturer_name,
                'brand_name': h.brand_name, 'part_number': h.part_number, 'serial_number': h.serial_number,
                'warehouse_number': h.warehouse_number, 'condition': h.condition, 'rack_label': h.rack_label,
                'recipient': h.recipient, 'date': h.date.isoformat(), 'notes': h.notes, 'batch_id': h.batch_id,
            }
            for h in Handover.objects.all()
        ],
        'low_stock_threshold': AppSettings.load().low_stock_threshold,
        'exported_at': date.today().isoformat(),
    }
    response = HttpResponse(json.dumps(payload, indent=2), content_type='application/json')
    response['Content-Disposition'] = f'attachment; filename="rack-inventory-backup-{date.today().isoformat()}.json"'
    ActivityLog.log('Backup', 'Data exported')
    return response


@require_POST
def settings_import(request):
    form = ImportFileForm(request.POST, request.FILES)
    if not form.is_valid():
        messages.error(request, 'Choose a backup file to import.')
        return redirect('settings')

    uploaded = form.cleaned_data['backup_file']
    is_csv = uploaded.name.lower().endswith('.csv')

    if is_csv:
        return _import_csv(request, uploaded)
    return _import_json(request, uploaded)


def _import_json(request, uploaded):
    try:
        data = json.loads(uploaded.read().decode('utf-8'))
    except (ValueError, UnicodeDecodeError):
        messages.error(request, 'That file is not valid JSON.')
        return redirect('settings')

    if not isinstance(data, dict) or 'racks' not in data or 'handovers' not in data:
        messages.error(request, 'That file does not look like a rack inventory backup.')
        return redirect('settings')

    valid_statuses = {c[0] for c in Device.STATUS_CHOICES}
    valid_conditions = {c[0] for c in Device.CONDITION_CHOICES}

    Device.objects.all().delete()
    Rack.objects.all().delete()
    Handover.objects.all().delete()

    for rack_data in data.get('racks', []):
        rack = Rack.objects.create(label=str(rack_data.get('label', 'Rack'))[:60])
        for dev in rack_data.get('devices', []):
            category_name = str(dev.get('category', '')).strip()[:60]
            serial = str(dev.get('serial_number', '')).strip()[:80]
            if not category_name or not serial:
                continue
            if Device.objects.filter(serial_number__iexact=serial).exists():
                continue
            category, _ = DeviceCategory.objects.get_or_create(name=category_name)
            brand = None
            brand_name = str(dev.get('brand', '')).strip()[:120]
            if brand_name:
                brand, _ = DeviceBrand.objects.get_or_create(category=category, name=brand_name)
            manufacturer = None
            manufacturer_name = str(dev.get('manufacturer', '')).strip()[:60]
            if manufacturer_name:
                manufacturer, _ = Manufacturer.objects.get_or_create(name=manufacturer_name)
            status = dev.get('status') if dev.get('status') in valid_statuses else Device.STATUS_AVAILABLE
            condition = dev.get('condition') if dev.get('condition') in valid_conditions else Device.CONDITION_GOOD
            Device.objects.create(
                rack=rack, category=category, brand=brand, manufacturer=manufacturer,
                part_number=str(dev.get('part_number', ''))[:80], serial_number=serial,
                warehouse_number=str(dev.get('warehouse_number', ''))[:80],
                status=status, condition=condition,
                location=str(dev.get('location', ''))[:120],
                description=str(dev.get('description', ''))[:2000],
            )

    for h in data.get('handovers', []):
        try:
            condition = h.get('condition') if h.get('condition') in valid_conditions else Device.CONDITION_GOOD
            Handover.objects.create(
                device_category=str(h.get('device_category', ''))[:60],
                manufacturer_name=str(h.get('manufacturer_name', ''))[:60],
                brand_name=str(h.get('brand_name', ''))[:120],
                part_number=str(h.get('part_number', ''))[:80],
                serial_number=str(h.get('serial_number', ''))[:80],
                warehouse_number=str(h.get('warehouse_number', ''))[:80],
                condition=condition,
                rack_label=str(h.get('rack_label', ''))[:60],
                recipient=str(h.get('recipient', ''))[:80],
                date=h.get('date') or date.today().isoformat(),
                notes=str(h.get('notes', ''))[:2000],
                batch_id=str(h.get('batch_id', ''))[:32],
            )
        except Exception:
            continue

    threshold = data.get('low_stock_threshold')
    if isinstance(threshold, int) and threshold > 0:
        settings_obj = AppSettings.load()
        settings_obj.low_stock_threshold = threshold
        settings_obj.save()

    ActivityLog.log('Backup', 'Data imported (JSON)')
    messages.success(request, 'Import complete.')
    return redirect('dashboard')


def _import_csv(request, uploaded):
    """
    Reads the same column layout produced by the CSV export:
    Type, Category, Manufacturer, Brand, PartNumber, SerialNumber,
    WarehouseNumber, Status, Condition, Location, Rack, Recipient, Date, Notes
    'Type' is either "Device" or "Handover". This REPLACES all current
    racks/devices/handovers, same as a JSON import.
    """
    try:
        text = uploaded.read().decode('utf-8-sig')
    except UnicodeDecodeError:
        messages.error(request, 'That file is not valid UTF-8 text.')
        return redirect('settings')

    reader = csv.DictReader(io.StringIO(text))
    required_cols = {'Type', 'Category', 'SerialNumber', 'Rack'}
    if not reader.fieldnames or not required_cols.issubset(set(reader.fieldnames)):
        messages.error(
            request,
            'That CSV doesn\'t have the expected columns. Export a CSV from this page first '
            'to see the exact format expected.',
        )
        return redirect('settings')

    rows = list(reader)
    valid_statuses = {c[0] for c in Device.STATUS_CHOICES}
    valid_conditions = {c[0] for c in Device.CONDITION_CHOICES}
    status_by_display = {c[1].lower(): c[0] for c in Device.STATUS_CHOICES}
    condition_by_display = {c[1].lower(): c[0] for c in Device.CONDITION_CHOICES}

    def resolve_status(value):
        value = (value or '').strip()
        if value in valid_statuses:
            return value
        return status_by_display.get(value.lower(), Device.STATUS_AVAILABLE)

    def resolve_condition(value):
        value = (value or '').strip()
        if value in valid_conditions:
            return value
        return condition_by_display.get(value.lower(), Device.CONDITION_GOOD)

    Device.objects.all().delete()
    Rack.objects.all().delete()
    Handover.objects.all().delete()

    rack_cache = {}

    def get_rack(label):
        label = (label or 'Rack').strip()[:60] or 'Rack'
        if label not in rack_cache:
            rack_cache[label] = Rack.objects.create(label=label)
        return rack_cache[label]

    device_count, handover_count, skipped = 0, 0, 0
    for row in rows:
        row_type = (row.get('Type') or '').strip().lower()
        category_name = (row.get('Category') or '').strip()[:60]
        serial = (row.get('SerialNumber') or '').strip()[:80]

        if row_type == 'device':
            if not category_name or not serial:
                skipped += 1
                continue
            if Device.objects.filter(serial_number__iexact=serial).exists():
                skipped += 1
                continue
            category, _ = DeviceCategory.objects.get_or_create(name=category_name)
            brand = None
            brand_name = (row.get('Brand') or '').strip()[:120]
            if brand_name:
                brand, _ = DeviceBrand.objects.get_or_create(category=category, name=brand_name)
            manufacturer = None
            manufacturer_name = (row.get('Manufacturer') or '').strip()[:60]
            if manufacturer_name:
                manufacturer, _ = Manufacturer.objects.get_or_create(name=manufacturer_name)
            Device.objects.create(
                rack=get_rack(row.get('Rack')), category=category, brand=brand, manufacturer=manufacturer,
                part_number=(row.get('PartNumber') or '')[:80], serial_number=serial,
                warehouse_number=(row.get('WarehouseNumber') or '')[:80],
                status=resolve_status(row.get('Status')), condition=resolve_condition(row.get('Condition')),
                location=(row.get('Location') or '')[:120], added_by=request.user,
            )
            device_count += 1
        elif row_type == 'handover':
            try:
                Handover.objects.create(
                    device_category=category_name, manufacturer_name=(row.get('Manufacturer') or '')[:60],
                    brand_name=(row.get('Brand') or '')[:120], part_number=(row.get('PartNumber') or '')[:80],
                    serial_number=serial, warehouse_number=(row.get('WarehouseNumber') or '')[:80],
                    condition=resolve_condition(row.get('Condition')),
                    rack_label=(row.get('Rack') or '')[:60], recipient=(row.get('Recipient') or '')[:80],
                    date=row.get('Date') or date.today().isoformat(), notes=(row.get('Notes') or '')[:2000],
                )
                handover_count += 1
            except Exception:
                skipped += 1
        else:
            skipped += 1

    ActivityLog.log('Backup', f'Data imported (CSV): {device_count} device(s), {handover_count} handover(s)')
    note = f' ({skipped} row(s) skipped)' if skipped else ''
    messages.success(request, f'CSV import complete — {device_count} device(s), {handover_count} handover(s){note}.')
    return redirect('dashboard')


@require_POST
def settings_reset(request):
    Device.objects.all().delete()
    Rack.objects.all().delete()
    Handover.objects.all().delete()
    ActivityLog.log('Reset', 'All inventory data cleared')
    messages.success(request, 'All inventory data cleared.')
    return redirect('dashboard')


# ---------- Local AI assistant (floating widget, available on every page) ----------
# No external API, no network call — see inventory/local_ai.py.

ASSISTANT_DISPLAY_KEY = 'assistant_display'


def assistant_history(request):
    return JsonResponse({'history': request.session.get(ASSISTANT_DISPLAY_KEY, [])})


@require_POST
def assistant_message(request):
    try:
        body = json.loads(request.body)
    except (ValueError, TypeError):
        return JsonResponse({'error': 'Malformed request.'}, status=400)

    user_message = (body.get('message') or '').strip()[:500]
    if not user_message:
        return JsonResponse({'error': 'Type a question first.'}, status=400)

    reply_text = answer_query(user_message, user=request.user, session=request.session)

    display_history = request.session.get(ASSISTANT_DISPLAY_KEY, [])
    display_history.append({'role': 'user', 'text': user_message})
    display_history.append({'role': 'assistant', 'text': reply_text})
    request.session[ASSISTANT_DISPLAY_KEY] = display_history[-40:]

    return JsonResponse({'reply': reply_text})


@require_POST
def assistant_clear(request):
    request.session[ASSISTANT_DISPLAY_KEY] = []
    return JsonResponse({'ok': True})


# ---------- Account management (superuser only) ----------

def _superuser_required(request):
    """Returns a redirect response if the requester isn't a superuser,
    otherwise None. Called at the top of every view in this section —
    template-level hiding of the nav link is a convenience, not the real
    guard; this is."""
    if not request.user.is_superuser:
        messages.error(request, "You don't have permission to manage accounts.")
        return redirect('dashboard')
    return None


def user_management_view(request):
    guard = _superuser_required(request)
    if guard:
        return guard
    users = User.objects.all().order_by('username')
    create_form = AdminUserCreateForm()
    return render(request, 'inventory/user_management.html', {
        'users': users, 'create_form': create_form,
    })


@require_POST
def user_create(request):
    guard = _superuser_required(request)
    if guard:
        return guard
    form = AdminUserCreateForm(request.POST)
    if form.is_valid():
        user = form.save(commit=False)
        user.is_staff = form.cleaned_data.get('is_staff', False)
        user.is_superuser = form.cleaned_data.get('is_superuser', False)
        user.save()
        ActivityLog.log('User created', f'{user.username} (by {request.user.username})')
        messages.success(request, f'Account "{user.username}" created.')
    else:
        for field, errs in form.errors.items():
            for err in errs:
                messages.error(request, err)
    return redirect('user_management')


@require_POST
def user_update(request, user_id):
    guard = _superuser_required(request)
    if guard:
        return guard
    target = get_object_or_404(User, id=user_id)
    form = AdminUserEditForm(request.POST, instance=target)
    if form.is_valid():
        if target == request.user and not form.cleaned_data['is_superuser']:
            messages.error(request, "You can't remove your own superuser status.")
            return redirect('user_management')
        if target == request.user and not form.cleaned_data['is_active']:
            messages.error(request, "You can't deactivate your own account.")
            return redirect('user_management')
        form.save()
        ActivityLog.log('User updated', f'{target.username} (by {request.user.username})')
        messages.success(request, f'Account "{target.username}" updated.')
    else:
        for field, errs in form.errors.items():
            for err in errs:
                messages.error(request, err)
    return redirect('user_management')


@require_POST
def user_delete(request, user_id):
    guard = _superuser_required(request)
    if guard:
        return guard
    target = get_object_or_404(User, id=user_id)
    if target == request.user:
        messages.error(request, "You can't delete your own account.")
        return redirect('user_management')
    if target.is_superuser and User.objects.filter(is_superuser=True).count() <= 1:
        messages.error(request, "You can't delete the last remaining superuser.")
        return redirect('user_management')
    username = target.username
    target.delete()
    ActivityLog.log('User deleted', f'{username} (by {request.user.username})')
    messages.success(request, f'Account "{username}" deleted.')
    return redirect('user_management')


@require_POST
def user_reset_password(request, user_id):
    guard = _superuser_required(request)
    if guard:
        return guard
    target = get_object_or_404(User, id=user_id)
    form = AdminPasswordResetForm(request.POST)
    if form.is_valid():
        target.password = make_password(form.cleaned_data['new_password1'])
        target.save(update_fields=['password'])
        ActivityLog.log('Password reset', f'{target.username} (by {request.user.username})')
        messages.success(request, f'Password updated for "{target.username}".')
    else:
        for field, errs in form.errors.items():
            for err in errs:
                messages.error(request, err)
    return redirect('user_management')
