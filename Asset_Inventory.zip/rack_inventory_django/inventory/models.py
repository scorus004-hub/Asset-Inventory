from django.conf import settings as django_settings
from django.db import models


class AppSettings(models.Model):
    """Singleton row holding app-wide settings."""
    low_stock_threshold = models.PositiveIntegerField(default=2)
    company_name = models.CharField(max_length=150, blank=True, help_text='Shown on generated handover documents.')
    warehouse_address = models.CharField(max_length=255, blank=True, help_text='Shown on generated handover documents.')

    @classmethod
    def load(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def __str__(self):
        return 'App settings'


class WebAuthnCredential(models.Model):
    """
    One registered passkey (Windows Hello, Touch ID, security key, etc.)
    belonging to a user. credential_id and public_key are stored as
    base64url text, which is how the `webauthn` library hands them back.
    """
    user = models.ForeignKey(django_settings.AUTH_USER_MODEL, related_name='webauthn_credentials', on_delete=models.CASCADE)
    nickname = models.CharField(max_length=60, blank=True)
    credential_id = models.CharField(max_length=255, unique=True)
    public_key = models.TextField()
    sign_count = models.PositiveIntegerField(default=0)
    transports = models.CharField(max_length=120, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_used_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.nickname or f'Passkey for {self.user}'


# ---------- Extensible lookup lists ----------
# Category and Manufacturer are simple pick-or-add lists. Brand is scoped
# to one Category (e.g. "Dell PowerVault MD3600i Dual Ports" only makes
# sense under Power Supply) — picking a Category on the Add Device form
# filters the Brand dropdown down to just that category's brands. All
# three are managed through small "+" popups on the Racks page rather than
# free text, so the same name is never spelled two different ways.

class DeviceCategory(models.Model):
    """The kind of device: Power Supply, SSD, HDD, FAN, RAM, etc. This is
    what totals are counted by — a Dell SSD and an HP SSD both count
    toward the same "SSD" total, regardless of brand."""
    name = models.CharField(max_length=60, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']
        verbose_name_plural = 'Device categories'

    def __str__(self):
        return self.name

    @classmethod
    def ensure_defaults(cls):
        for n in ['Power Supply', 'SSD', 'HDD', 'FAN', 'RAM']:
            cls.objects.get_or_create(name=n)


class Manufacturer(models.Model):
    """A company that makes devices: Dell, HP, HPE, etc. Not scoped to a
    category — the same manufacturer can make many kinds of device."""
    name = models.CharField(max_length=80, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name

    @classmethod
    def ensure_defaults(cls):
        for n in ['Dell', 'HP', 'HPE']:
            cls.objects.get_or_create(name=n)


class DeviceBrand(models.Model):
    """A specific brand/model line, scoped to one Device Category — e.g.
    "Dell PowerVault MD3600i Dual Ports" only makes sense under Power
    Supply. Picking a Category on the Add Device form filters this list
    down to brands that belong to that category."""
    category = models.ForeignKey(DeviceCategory, related_name='brands', on_delete=models.CASCADE)
    name = models.CharField(max_length=150)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']
        constraints = [models.UniqueConstraint(fields=['category', 'name'], name='unique_brand_per_category')]

    def __str__(self):
        return f'{self.name} ({self.category.name})'


class CategoryAttribute(models.Model):
    """
    A custom detail field scoped to one Device Category — e.g. SSD might
    have Type, Capacity, Speed, Size; Power Supply might just have
    Capacity. Fully user-managed from the Add Device popup: add a new one
    on the fly, rename it, or delete it, per category. Values entered for
    a unit are stored in that Device's `attributes` JSON field, keyed by
    this attribute's name — deleting the definition later only stops it
    being offered going forward, it doesn't erase values already saved on
    existing units.
    """
    category = models.ForeignKey(DeviceCategory, related_name='attributes', on_delete=models.CASCADE)
    name = models.CharField(max_length=60)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['id']
        constraints = [models.UniqueConstraint(fields=['category', 'name'], name='unique_attribute_per_category')]

    def __str__(self):
        return f'{self.name} ({self.category.name})'


class Rack(models.Model):
    label = models.CharField(max_length=60)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return self.label

    def total_units(self):
        return self.devices.count()

    def grouped_devices(self):
        """
        Group this rack's individual serialized units by CATEGORY (Power
        Supply / SSD / HDD / FAN / RAM / ...) — so the total shown is "how
        many SSDs" no matter the brand or manufacturer (a Dell SSD and an
        HP SSD both count toward the same SSD total). Each unit underneath
        keeps its own brand, manufacturer, serial number, part number,
        warehouse number, status, condition, location, description, and
        who/when it was added.
        """
        groups = {}
        order = []
        units = (
            self.devices
            .select_related('category', 'brand', 'manufacturer', 'added_by')
            .order_by('category__name', 'brand__name', 'created_at')
        )
        for unit in units:
            key = unit.category_id
            if key not in groups:
                groups[key] = {'category': unit.category, 'units': []}
                order.append(key)
            groups[key]['units'].append(unit)
        result = []
        for key in order:
            g = groups[key]
            g['count'] = len(g['units'])
            result.append(g)
        return result

    def add_device_unit(self, category, serial_number, brand=None, manufacturer=None,
                         status=None, condition=None, part_number='', warehouse_number='',
                         location='', description='', added_by=None, attributes=None,
                         unit_name='unit', unit_price=None, contract_code='', station_code=''):
        """
        Add ONE physical, serialized unit to this rack. Each unit is its
        own row (a serial number can't be shared between two units); the
        Racks page groups rows by category so totals (e.g. "3 SSDs")
        update automatically regardless of brand. Raises ValueError if the
        serial number is already in use anywhere in the inventory.
        """
        serial_number = serial_number.strip()
        if Device.objects.filter(serial_number__iexact=serial_number).exists():
            raise ValueError(f'Serial number "{serial_number}" is already in the inventory.')
        return self.devices.create(
            category=category, brand=brand, manufacturer=manufacturer,
            status=status or Device.STATUS_AVAILABLE, condition=condition or Device.CONDITION_NEW,
            part_number=part_number.strip(), serial_number=serial_number,
            warehouse_number=warehouse_number.strip(), location=location.strip(),
            description=description.strip(), added_by=added_by, attributes=attributes or {},
            unit_name=(unit_name or 'unit').strip(), unit_price=unit_price,
            contract_code=contract_code.strip(), station_code=station_code.strip(),
        )


class Device(models.Model):
    """
    One physical, serialized unit (an individual SSD, HDD, Power Supply,
    etc.) — not an aggregate count. Units that share a category are
    grouped together for display (see Rack.grouped_devices), but each row
    keeps its own brand, manufacturer, serial number, part number,
    warehouse number, status, condition, location, description, and
    who/when it was added.
    """
    NEW = 'NEW'
    USED = 'USED'
    GOOD = 'GOOD'
    NEW_ARRIVAL = 'NEW_ARRIVAL'
    CONDITION_NEW = NEW
    CONDITION_USED = USED
    CONDITION_GOOD = GOOD
    CONDITION_NEW_ARRIVAL = NEW_ARRIVAL
    CONDITION_CHOICES = [(NEW, 'New'), (USED, 'Used'), (GOOD, 'Good'), (NEW_ARRIVAL, 'New Arrival')]

    STATUS_AVAILABLE = 'AVAILABLE'
    STATUS_IN_USE = 'IN_USE'
    STATUS_RESERVED = 'RESERVED'
    STATUS_FAULTY = 'FAULTY'
    STATUS_CHOICES = [
        (STATUS_AVAILABLE, 'Available'), (STATUS_IN_USE, 'In Use'),
        (STATUS_RESERVED, 'Reserved'), (STATUS_FAULTY, 'Faulty'),
    ]

    rack = models.ForeignKey(Rack, related_name='devices', on_delete=models.CASCADE)
    category = models.ForeignKey(DeviceCategory, related_name='devices', on_delete=models.PROTECT)
    brand = models.ForeignKey(DeviceBrand, null=True, blank=True, related_name='devices', on_delete=models.SET_NULL)
    manufacturer = models.ForeignKey(Manufacturer, null=True, blank=True, related_name='devices', on_delete=models.SET_NULL)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default=STATUS_AVAILABLE)
    condition = models.CharField(max_length=15, choices=CONDITION_CHOICES, default=NEW)
    part_number = models.CharField(max_length=80, blank=True)
    serial_number = models.CharField(max_length=80, unique=True)
    warehouse_number = models.CharField(max_length=80, blank=True)
    location = models.CharField(max_length=120, blank=True)
    description = models.TextField(blank=True)
    unit_name = models.CharField(
        max_length=30, blank=True, default='unit',
        help_text='Unit of measure for the handover document, e.g. "unit", "pcs", "bộ".',
    )
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    contract_code = models.CharField(max_length=60, blank=True)
    station_code = models.CharField(max_length=60, blank=True)
    attributes = models.JSONField(
        default=dict, blank=True,
        help_text='Category-specific detail (e.g. Capacity, Speed, Type for SSD), keyed by CategoryAttribute name.',
    )
    added_by = models.ForeignKey(
        django_settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='devices_added',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['category__name', 'serial_number']

    def __str__(self):
        return f'{self.category.name} — SN:{self.serial_number} ({self.rack.label})'

    @property
    def label(self):
        bits = [self.category.name]
        if self.manufacturer:
            bits.append(self.manufacturer.name)
        if self.brand:
            bits.append(self.brand.name)
        bits.append(f'SN:{self.serial_number}')
        return ' — '.join(bits)


class Handover(models.Model):
    """
    Snapshot record of a single serialized unit being handed over. Stores
    the unit's details as text (not a foreign key) so history stays intact
    even after the Device row itself is deleted (it leaves the rack once
    handed over). Multiple units handed over together in one submission
    each get their own row here, sharing recipient/date/notes.
    """
    device_category = models.CharField(max_length=60)
    brand_name = models.CharField(max_length=150, blank=True)
    manufacturer_name = models.CharField(max_length=80, blank=True)
    condition = models.CharField(max_length=15, choices=Device.CONDITION_CHOICES, default=Device.NEW)
    part_number = models.CharField(max_length=80, blank=True)
    serial_number = models.CharField(max_length=80, blank=True)
    warehouse_number = models.CharField(max_length=80, blank=True)
    attributes = models.JSONField(default=dict, blank=True)
    rack_label = models.CharField(max_length=60)
    unit_name = models.CharField(max_length=30, blank=True, default='unit')
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    contract_code = models.CharField(max_length=60, blank=True)
    station_code = models.CharField(max_length=60, blank=True)

    # --- Party B / Receiver — who the equipment is being handed to ---
    recipient = models.CharField(max_length=80, help_text='Receiver name')
    receiver_company = models.CharField(max_length=120, blank=True)
    receiver_position = models.CharField(max_length=80, blank=True)
    receiver_phone = models.CharField(max_length=40, blank=True)

    # --- Party A / Delivery — who is handing the equipment over ---
    sender_name = models.CharField(max_length=80, blank=True)
    sender_position = models.CharField(max_length=80, blank=True)
    sender_phone = models.CharField(max_length=40, blank=True)

    # --- Optional third party who physically transports the equipment ---
    transportation_name = models.CharField(max_length=80, blank=True)

    location = models.CharField(
        max_length=200, blank=True,
        help_text='Where the handover took place, e.g. "Warehouse in Bebonuk, Dili, Timor-Leste".',
    )

    equipment_status = models.CharField(
        max_length=150, blank=True,
        help_text='e.g. "Hand over old server", "Broken — needs repair", "Working — reassigned"',
    )

    date = models.DateField()
    notes = models.TextField(blank=True)
    batch_id = models.CharField(
        max_length=32, blank=True, db_index=True,
        help_text='Groups units handed over together in one submission, for a single printable document.',
    )
    handed_over_by = models.ForeignKey(
        django_settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='handovers_recorded',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f'{self.device_category} (SN:{self.serial_number}) -> {self.recipient}'


class ActivityLog(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    action = models.CharField(max_length=100)
    details = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f'{self.action}: {self.details}'

    @classmethod
    def log(cls, action, details=''):
        cls.objects.create(action=action, details=details)
        # Keep the log from growing unbounded.
        ids_to_keep = cls.objects.order_by('-timestamp').values_list('id', flat=True)[:500]
        cls.objects.exclude(id__in=list(ids_to_keep)).delete()
