from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    path('webauthn/register/begin/', views.webauthn_register_begin, name='webauthn_register_begin'),
    path('webauthn/register/complete/', views.webauthn_register_complete, name='webauthn_register_complete'),
    path('webauthn/login/begin/', views.webauthn_login_begin, name='webauthn_login_begin'),
    path('webauthn/login/complete/', views.webauthn_login_complete, name='webauthn_login_complete'),
    path('webauthn/credentials/<int:cred_id>/delete/', views.webauthn_credential_delete, name='webauthn_credential_delete'),

    path('', views.dashboard_view, name='dashboard'),

    path('racks/', views.racks_view, name='racks'),
    path('racks/add/', views.rack_add, name='rack_add'),
    path('racks/<int:rack_id>/', views.rack_detail_view, name='rack_detail'),
    path('racks/<int:rack_id>/rename/', views.rack_rename, name='rack_rename'),
    path('racks/<int:rack_id>/delete/', views.rack_delete, name='rack_delete'),
    path('racks/<int:rack_id>/devices/add/', views.device_add, name='device_add'),
    path('categories/add/', views.category_quick_add, name='category_quick_add'),
    path('brands/add/', views.brand_quick_add, name='brand_quick_add'),
    path('manufacturers/add/', views.manufacturer_quick_add, name='manufacturer_quick_add'),
    path('categories/<int:category_id>/brands/', views.brands_for_category, name='brands_for_category'),
    path('categories/<int:category_id>/attributes/', views.attributes_for_category, name='attributes_for_category'),
    path('attributes/add/', views.category_attribute_quick_add, name='category_attribute_quick_add'),
    path('attributes/<int:attr_id>/rename/', views.category_attribute_rename, name='category_attribute_rename'),
    path('attributes/<int:attr_id>/delete/', views.category_attribute_delete, name='category_attribute_delete'),
    path('devices/<int:device_id>/', views.device_detail_view, name='device_detail'),
    path('devices/<int:device_id>/qr/', views.device_qr, name='device_qr'),
    path('devices/<int:device_id>/delete/', views.device_delete, name='device_delete'),

    path('scan/', views.scan_view, name='scan'),

    path('assistant/history/', views.assistant_history, name='assistant_history'),
    path('assistant/message/', views.assistant_message, name='assistant_message'),
    path('assistant/clear/', views.assistant_clear, name='assistant_clear'),

    path('handover/', views.handover_view, name='handover'),
    path('handover/<str:batch_id>/print/', views.handover_print, name='handover_print'),
    path('handover/<str:batch_id>/document/', views.handover_docx, name='handover_docx'),

    path('search/', views.search_view, name='search'),
    path('reports/', views.reports_view, name='reports'),
    path('reports/export/', views.reports_export, name='reports_export'),
    path('activity/', views.activity_view, name='activity'),

    path('settings/', views.settings_view, name='settings'),
    path('settings/company/', views.settings_company_save, name='settings_company_save'),
    path('settings/export/', views.settings_export, name='settings_export'),
    path('settings/export/csv/', views.settings_export_csv, name='settings_export_csv'),
    path('settings/import/', views.settings_import, name='settings_import'),
    path('settings/reset/', views.settings_reset, name='settings_reset'),

    path('settings/users/', views.user_management_view, name='user_management'),
    path('settings/users/create/', views.user_create, name='user_create'),
    path('settings/users/<int:user_id>/update/', views.user_update, name='user_update'),
    path('settings/users/<int:user_id>/delete/', views.user_delete, name='user_delete'),
    path('settings/users/<int:user_id>/reset-password/', views.user_reset_password, name='user_reset_password'),
]
