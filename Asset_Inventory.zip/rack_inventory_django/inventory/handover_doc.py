"""
Builds a downloadable .docx handover document, structured to match the
organization's own handover template: title, date/address, a Delivery
party block and a Receiver party block (each with name/position/phone), an
equipment table (with unit name, price, contract code, station code), an
equipment-status note, a copies statement, and two or three signature
blocks (a third "Transportation" column appears only if that name was
given). Uses python-docx; no external service involved.
"""
import io

from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH


def _set_cell_text(cell, text, bold=False):
    cell.text = text
    for p in cell.paragraphs:
        for r in p.runs:
            r.bold = bold


def build_handover_docx(items, company_name='', warehouse_address=''):
    """items: a list of Handover model instances sharing one batch_id.
    Returns raw .docx bytes."""
    doc = Document()

    for section in doc.sections:
        section.left_margin = Cm(2)
        section.right_margin = Cm(2)

    first = items[0]

    title = doc.add_heading((company_name or 'Asset') + ' Equipment Handover Document', level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    meta.add_run(f'Date: {first.date}')
    loc = first.location or warehouse_address
    if loc:
        meta.add_run(f'  •  Address: {loc}')

    doc.add_paragraph('The parties below confirm the following equipment handover:')

    # --- Party A: Delivery ---
    doc.add_paragraph('Party A — Delivery', style='Heading 2')
    party_a = doc.add_table(rows=1, cols=2)
    party_a.style = 'Light Grid Accent 1'
    _set_cell_text(party_a.rows[0].cells[0], f'Name: {first.sender_name or "—"}')
    pos_phone = f'Position: {first.sender_position or "—"}\nPhone: {first.sender_phone or "—"}'
    _set_cell_text(party_a.rows[0].cells[1], pos_phone)

    # --- Party B: Receiver ---
    doc.add_paragraph('Party B — Receiver', style='Heading 2')
    party_b = doc.add_table(rows=1, cols=2)
    party_b.style = 'Light Grid Accent 1'
    name_company = f'Name: {first.recipient}'
    if first.receiver_company:
        name_company += f'\nCompany: {first.receiver_company}'
    _set_cell_text(party_b.rows[0].cells[0], name_company)
    pos_phone_b = f'Position: {first.receiver_position or "—"}\nPhone: {first.receiver_phone or "—"}'
    _set_cell_text(party_b.rows[0].cells[1], pos_phone_b)

    doc.add_paragraph()
    doc.add_paragraph(f'Equipment list ({len(items)} item{"s" if len(items) != 1 else ""}):', style='Heading 2')

    headers = ['No', 'Equipment name', 'Serial number', 'Part number', 'Unit name',
               "Q'ty", 'Unit price', 'Contract code', 'Station code']
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = 'Light Grid Accent 1'
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        _set_cell_text(hdr_cells[i], h, bold=True)

    for idx, h in enumerate(items, start=1):
        row = table.add_row().cells
        equip_name = h.device_category
        if h.manufacturer_name or h.brand_name:
            equip_name += f' ({" ".join(filter(None, [h.manufacturer_name, h.brand_name]))})'
        values = [
            str(idx), equip_name, h.serial_number or '—', h.part_number or '—',
            h.unit_name or 'unit', '1',
            f'{h.unit_price:,.2f}' if h.unit_price is not None else '—',
            h.contract_code or '—', h.station_code or '—',
        ]
        for i, v in enumerate(values):
            row[i].text = v

    doc.add_paragraph()
    if first.equipment_status:
        doc.add_paragraph(f'Equipment status: {first.equipment_status}')
    if first.notes:
        doc.add_paragraph(f'Notes: {first.notes}')

    doc.add_paragraph()
    doc.add_paragraph(
        'This document is issued in duplicate; each party retains one copy, '
        'effective from the date of signing. By signing below, both parties '
        'confirm the item(s) listed above were physically handed over on the date stated.'
    )
    doc.add_paragraph()

    sig_cols = 3 if first.transportation_name else 2
    sig_table = doc.add_table(rows=4, cols=sig_cols)
    sig_table.autofit = True
    _set_cell_text(sig_table.cell(0, 0), 'DELIVERY\n(Sign & full name)', bold=True)
    if sig_cols == 3:
        _set_cell_text(sig_table.cell(0, 1), 'TRANSPORTATION\n(Sign & full name)', bold=True)
        _set_cell_text(sig_table.cell(0, 2), 'RECEIVER\n(Sign & full name)', bold=True)
    else:
        _set_cell_text(sig_table.cell(0, 1), 'RECEIVER\n(Sign & full name)', bold=True)

    for col in range(sig_cols):
        sig_table.cell(1, col).text = '\n\n_______________________________'

    receiver_col = sig_cols - 1
    sig_table.cell(2, 0).text = f'Name: {first.sender_name or "____________________"}'
    if sig_cols == 3:
        sig_table.cell(2, 1).text = f'Name: {first.transportation_name}'
    sig_table.cell(2, receiver_col).text = f'Name: {first.recipient}'

    for col in range(sig_cols):
        sig_table.cell(3, col).text = 'Date: ______________________________'

    for row in sig_table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                p.paragraph_format.space_before = Pt(6)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
