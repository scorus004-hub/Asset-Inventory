import io
from django.http import HttpResponse


def qr_png_response(data, box_size=8):
    """Generate a QR code PNG for `data` (usually an absolute URL) and
    return it as an HttpResponse image."""
    import qrcode

    img = qrcode.make(data, box_size=box_size, border=2)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return HttpResponse(buf.getvalue(), content_type="image/png")
