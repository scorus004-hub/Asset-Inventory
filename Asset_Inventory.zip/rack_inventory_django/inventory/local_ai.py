"""
A small, fully local "AI" for this inventory — no external API, no network
call, no API key. It answers by running real database queries (and, for
add/delete, real database writes) against whatever it recognizes in your
message:

  1. Greetings ("hi", "hello", "good morning")        -> friendly welcome
  2. Self-description ("what can you do", "help me")   -> explains itself
  3. "Add a device ... category ... rack ..."            -> creates a unit
  4. "Delete/remove the device with serial ..."           -> removes a unit
  5. "Where is / locate / find <something>"               -> location + link
  6. "Who has / who took / handed over <something>"        -> handover history
  7. "How many <category> do I have"                        -> counts
  8. "Thanks" / "thank you"                                  -> acknowledgment

It's intentionally simple (keyword + regex matching, not a language model)
and scoped only to this system's own data — it can't browse the web and
can't answer general questions. Add/delete require the requesting user to
be logged in (always true here, since every page requires login) and are
logged to the Activity log exactly like the equivalent UI action, so
there's always an audit trail of what the assistant changed. Deletes
require an exact serial number on purpose — no bulk or fuzzy deletes via
chat. Greeting detection uses word boundaries so it won't misfire on words
like "Hitachi" that merely contain "hi".
"""
import re
import uuid

from django.db.models import Q
from django.urls import reverse

from .models import ActivityLog, Device, DeviceCategory, Handover, Rack

STOPWORDS = {
    'the', 'a', 'an', 'is', 'are', 'in', 'my', 'of', 'for', 'to', 'do', 'i', 'have',
    'has', 'where', 'who', 'how', 'many', 'find', 'locate', 'location', 'device',
    'devices', 'me', 'tell', 'you', 'did', 'was', 'it', 'that', 'this', 'give',
    'gave', 'took', 'take', 'and', 'or', 'please', 'can', 'total', 'count',
}

GREETING_WORDS = re.compile(r'\b(hello|hi|hey|yo|sup)\b')
GREETING_PHRASES = ['good morning', 'good afternoon', 'good evening', "what's up", 'howdy']
THANKS_TRIGGERS = ['thank you', 'thanks', 'thx', 'appreciate it']
ABOUT_TRIGGERS = [
    'who are you', 'what are you', 'what can you do', 'what do you do', 'help me',
    'what is this', "what's this", 'how do you work', 'how does this work',
    'what do you know', 'do you know everything', 'are you an ai', 'are you claude',
    'are you chatgpt', 'are you a bot', 'what are your capabilities', 'how can you help',
    'what services', 'how do you support',
]
ADD_TRIGGERS = ['add a device', 'add device', 'add new device', 'add a new device',
                'create a device', 'register a device', 'add an item', 'add this device']
DELETE_TRIGGERS = ['delete device', 'delete the device', 'remove device', 'remove the device',
                    'delete serial', 'remove serial', 'delete a device', 'remove a device']
LOCATE_TRIGGERS = ['where', 'locate', 'find', 'location of']
WHO_TRIGGERS = ['who has', 'who took', 'who received', 'who got', 'handed over',
                'hand over', 'gave to', 'who did i give', 'who does', 'given to']
COUNT_TRIGGERS = ['how many', 'count of', 'total number', 'how much']

ABOUT_BLURB = (
    "I'm the assistant built directly into this inventory system — no external AI, "
    "no internet connection, just real queries (and, when you ask, real changes) "
    "against your own database, running right here on this server.\n\n"
    "Here's what I can actually do for you:\n"
    "• 🔎 Locate a device and hand you a direct link to it — \"where is the Dell SSD\"\n"
    "• 👤 Tell you who a device was handed over to and when — \"who has the HP RAM\"\n"
    "• 🔢 Count how many of something you have — \"how many fans do I have\"\n"
    "• ➕ Add a device to a rack — \"add a device, category SSD, rack Rack 01, serial ABC123\" "
    "all at once, or just say \"add a device\" and I'll ask for what's missing, one step at a time\n"
    "• ➖ Remove a specific device by serial number — \"delete the device with serial ABC123\"\n\n"
    "I know everything already stored here: every rack, category, brand, manufacturer, "
    "serial number, part number, warehouse number, status, condition, location, and "
    "full handover history — so I can search across all of it at once.\n\n"
    "I can't browse the web or chat about anything outside this inventory, and any "
    "add/remove I do gets logged in the Activity log just like doing it by hand."
)


def _terms(message):
    words = re.findall(r"[A-Za-z0-9\-]+", message)
    return [w for w in words if w.lower() not in STOPWORDS and len(w) > 1]


def _device_filter(terms):
    filt = Q()
    for t in terms:
        filt |= (
            Q(category__name__icontains=t) | Q(brand__name__icontains=t) |
            Q(manufacturer__name__icontains=t) | Q(serial_number__icontains=t) |
            Q(part_number__icontains=t) | Q(warehouse_number__icontains=t) |
            Q(location__icontains=t) | Q(status__icontains=t) | Q(condition__icontains=t)
        )
    return filt


def _handover_filter(terms):
    filt = Q()
    for t in terms:
        filt |= (
            Q(device_category__icontains=t) | Q(brand_name__icontains=t) |
            Q(manufacturer_name__icontains=t) | Q(serial_number__icontains=t) |
            Q(part_number__icontains=t) | Q(recipient__icontains=t)
        )
    return filt


def _find_rack(msg):
    for r in Rack.objects.all():
        if r.label.lower() in msg:
            return r
    m = re.search(r'rack\s*#?\s*0*(\d+)', msg)
    if m:
        num = m.group(1)
        for r in Rack.objects.all():
            if re.search(rf'\b0*{num}\b', r.label):
                return r
    return None


def _find_category(msg):
    for cat in DeviceCategory.objects.all():
        if cat.name.lower() in msg:
            return cat
    return None


def _extract_serial(message):
    m = re.search(r'serial(?:\s*number|\s*no\.?|\s*#)?\s*[:\-]?\s*([A-Za-z0-9\-]{3,40})', message, re.IGNORECASE)
    return m.group(1) if m else None


def _describe_device(d):
    bits = [d.category.name]
    if d.manufacturer:
        bits.append(d.manufacturer.name)
    if d.brand:
        bits.append(d.brand.name)
    return ' '.join(bits)


def _answer_locate(terms):
    if not terms:
        return ("Tell me a category, brand, manufacturer, serial number, or "
                "warehouse number to look up — e.g. \"where is the Dell power supply\".")
    matches = Device.objects.select_related('rack', 'category', 'brand', 'manufacturer').filter(_device_filter(terms))[:8]
    if not matches:
        return "I couldn't find anything matching that in the inventory."
    lines = []
    for d in matches:
        loc = f"{d.rack.label}" + (f", {d.location}" if d.location else "")
        link = reverse('device_detail', args=[d.id])
        lines.append(f"• {_describe_device(d)} (SN: {d.serial_number or '—'}) is in {loc}. → {link}")
    return '\n'.join(lines)


def _answer_who(terms):
    if not terms:
        return ("Tell me which device — a category, brand, serial number, or "
                "recipient name — e.g. \"who has the HP RAM\".")
    matches = Handover.objects.filter(_handover_filter(terms)).order_by('-date')[:8]
    if not matches:
        return "I don't see a handover record matching that."
    lines = []
    for h in matches:
        bits = [h.device_category]
        if h.manufacturer_name:
            bits.append(h.manufacturer_name)
        if h.brand_name:
            bits.append(h.brand_name)
        lines.append(f"• {' '.join(bits)} (SN: {h.serial_number or '—'}) was handed to {h.recipient} on {h.date}.")
    return '\n'.join(lines)


def _answer_count(message, terms):
    msg = message.lower()
    for cat in DeviceCategory.objects.all():
        if cat.name.lower() in msg:
            n = Device.objects.filter(category=cat).count()
            noun = cat.name if n == 1 else f'{cat.name}s'
            return f'You have {n} {noun} in total, across all racks.'
    if terms:
        n = Device.objects.filter(_device_filter(terms)).count()
        if n:
            return f'I found {n} matching unit(s).'
    total = Device.objects.count()
    return f'You have {total} device unit(s) in total across the inventory.'


def _answer_greeting():
    total = Device.objects.count()
    category_count = DeviceCategory.objects.count()
    extra = ''
    if total:
        extra = f" Right now I'm tracking {total} unit(s) across {category_count} categor{'y' if category_count == 1 else 'ies'}."
    return (
        "Hey there! 👋 I'm your inventory assistant." + extra + " Ask me to locate a "
        "device, tell you who it was handed over to, or count how many of "
        "something you have — try \"where is the Dell SSD\" or \"how many HDDs "
        "do I have\"."
    )


def _answer_about():
    return ABOUT_BLURB


def _answer_thanks():
    return "You're welcome! Let me know if you need anything else. 🙂"


def _answer_add(message, user, session=None):
    msg = message.lower()
    pending = session.get('pending_add') if session is not None else None

    category = _find_category(msg)
    if not category and pending and pending.get('category_id'):
        category = DeviceCategory.objects.filter(id=pending['category_id']).first()

    rack = _find_rack(msg)
    if not rack and pending and pending.get('rack_id'):
        rack = Rack.objects.filter(id=pending['rack_id']).first()

    serial = _extract_serial(message) or (pending.get('serial') if pending else None)

    if not category:
        if session is not None:
            session['pending_add'] = {'rack_id': rack.id if rack else None, 'serial': serial}
        names = ', '.join(c.name for c in DeviceCategory.objects.all()[:12])
        if not names:
            if session is not None:
                session.pop('pending_add', None)
            return "You don't have any device categories yet — add one from the Racks page first, then I can add units to it."
        return f"Which category should this be? Tell me one of: {names}."

    if not rack:
        if session is not None:
            session['pending_add'] = {'category_id': category.id, 'serial': serial}
        labels = ', '.join(r.label for r in Rack.objects.all()[:12])
        if not labels:
            if session is not None:
                session.pop('pending_add', None)
            return "You don't have any racks yet — add one from the Racks page first, then I can add a device to it."
        return f"Got it, a {category.name}. Which rack should I put it in? You have: {labels}."

    auto_generated = False
    if not serial:
        serial = f"AI-{uuid.uuid4().hex[:8].upper()}"
        auto_generated = True

    try:
        device = rack.add_device_unit(
            category=category, serial_number=serial, added_by=user,
            description='Added via AI assistant.',
        )
    except ValueError as exc:
        if session is not None:
            session['pending_add'] = {'category_id': category.id, 'rack_id': rack.id}
        return f"{exc} Give me a different serial number for it, or tell me to delete that one first."

    if session is not None:
        session.pop('pending_add', None)

    ActivityLog.log('Device added', f'{category.name} (SN: {device.serial_number}) in {rack.label} — via AI assistant')
    link = reverse('device_detail', args=[device.id])
    note = f" I generated a serial number for it since you didn't give one: {serial}." if auto_generated else ""
    return f"Done — added a {category.name} (SN: {device.serial_number}) to {rack.label}.{note} → {link}"


def _answer_delete(message, user):
    serial = _extract_serial(message)
    if not serial:
        return ("Give me the exact serial number of the device to delete — e.g. "
                "\"delete the device with serial ABC123\". I won't delete based on category "
                "or brand alone, to avoid removing the wrong thing.")

    device = Device.objects.select_related('rack', 'category').filter(serial_number__iexact=serial).first()
    if not device:
        return f"I couldn't find a device with serial \"{serial}\" — nothing was deleted."

    description = f'{device.category.name} (SN: {device.serial_number}) from {device.rack.label}'
    device.delete()
    ActivityLog.log('Device removed', f'{description} — via AI assistant')
    return f"Done — removed {description}."


def answer_query(message, user=None, session=None):
    """Takes the raw message, the requesting user (needed for add/delete so
    changes get attributed and logged), and optionally the Django session
    (needed only so an in-progress "add a device" conversation can carry
    across messages — e.g. you say "add a device", I ask which category,
    you reply "SSD", I ask which rack, you reply "Rack 03" and it's done).
    Without a session it still works, just one-shot only. No external
    calls either way."""
    message = (message or '').strip()
    if not message:
        return "Ask me something like \"where is the Dell SSD\" or \"who has the HP RAM\"."

    msg = message.lower()
    terms = _terms(message)

    # Pure greetings only (word-boundary matched, so "Hitachi" never
    # trips the "hi" trigger) — if there's real content beyond the
    # greeting itself, fall through and answer the actual question too.
    is_greeting = bool(GREETING_WORDS.search(msg)) or any(p in msg for p in GREETING_PHRASES)
    if is_greeting and len(terms) <= 1:
        if session is not None:
            session.pop('pending_add', None)
        return _answer_greeting()

    if any(t in msg for t in THANKS_TRIGGERS):
        return _answer_thanks()
    if any(t in msg for t in ABOUT_TRIGGERS):
        return _answer_about()

    other_intent = any(t in msg for t in DELETE_TRIGGERS + WHO_TRIGGERS + COUNT_TRIGGERS + LOCATE_TRIGGERS)
    pending_add = session.get('pending_add') if session is not None else None
    if pending_add and not other_intent:
        # A category/rack name typed alone (answering my last question)
        # won't match ADD_TRIGGERS, so check pending state before that.
        return _answer_add(message, user, session)
    if pending_add and other_intent and session is not None:
        session.pop('pending_add', None)  # user moved on to something else

    if any(t in msg for t in ADD_TRIGGERS):
        return _answer_add(message, user, session)
    if any(t in msg for t in DELETE_TRIGGERS):
        return _answer_delete(message, user)
    if any(t in msg for t in WHO_TRIGGERS):
        return _answer_who(terms)
    if any(t in msg for t in COUNT_TRIGGERS):
        return _answer_count(message, terms)
    if any(t in msg for t in LOCATE_TRIGGERS):
        return _answer_locate(terms)

    # No recognized trigger phrase — fall back to a best-effort locate,
    # since "look up X" is the most common intent.
    if terms:
        return _answer_locate(terms)
    return (
        "I can help you locate a device, find who it was handed over to, "
        "count how many of a category you have, or add/remove a device — "
        "try \"where is the Dell SSD\", \"who has the HP RAM\", or \"how many "
        "fans do I have\". Ask \"what can you do\" any time for a refresher."
    )
