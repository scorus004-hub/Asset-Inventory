TAB_MAP = {
    'dashboard': 'dashboard',
    'racks': 'racks',
    'handover': 'handover',
    'scan': 'scan',
    'search': 'search',
    'reports': 'reports',
    'activity': 'activity',
    'settings': 'settings',
    'user_management': 'user_management',
}


def active_tab(request):
    url_name = getattr(request.resolver_match, 'url_name', None) if request.resolver_match else None
    return {'active_tab': TAB_MAP.get(url_name, '')}
