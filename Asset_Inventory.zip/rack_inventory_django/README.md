# Rack Inventory (Django)

A Django app for tracking devices stored across racks — with a proper
reference-data system for device categories/brands/manufacturers, full
per-unit detail (serial, part number, warehouse number, status, condition,
location), multi-select handovers with printable documents, QR labels,
reporting, a fully local AI assistant, and real accounts with passkey
(WebAuthn) login. Sidebar layout, Bootstrap 5 throughout.

## Latest additions

- **Draggable AI bubble** — grab and drag the assistant icon anywhere on
  screen; its position is remembered per-browser. A short-movement
  threshold tells a drag apart from a normal click, so it still opens
  normally on tap.
- **Conversational "add a device"** — ask the assistant to add a device
  and, if you don't give everything at once, it remembers what you've said
  so far across the conversation and asks only for what's missing (category
  → rack → done), instead of making you restate everything each time.
- **ngrok integration** — `python manage.py runserver_ngrok` starts a
  tunnel using your own `NGROK_AUTHTOKEN` and automatically trusts the
  resulting public URL for `ALLOWED_HOSTS`/CSRF/WebAuthn — no manual
  settings edits. See "Configuration" below.
- **Handover document now matches a real handover form** — Party A
  (Delivery) and Party B (Receiver) each get name/position/phone, plus
  company, warehouse address, transportation, equipment status, contract
  code, and station code — and the generated Word document mirrors that
  layout with a two- or three-way signature block.
- **Selected items visibly enter a table** on the Handover page as you
  check them off the picker (and leave when unchecked), instead of a
  plain text summary.
- **CSV import** alongside JSON — Settings → Backup accepts either file
  type in the same Import button; the app tells the two apart by
  extension.
- **Account management for superusers** — add, edit, deactivate, delete,
  and reset passwords for other accounts from Settings → Manage accounts,
  without touching `/admin/` or the command line. Self-lockout is blocked
  (a superuser can't demote/deactivate/delete their own account, and the
  last superuser can't be deleted).

## What's in this version

### Device tracking
- **Device Name is a managed list, not free text** — Power Supply, SSD,
  HDD, FAN, RAM, etc. Pick one from a dropdown on the Add Device popup; if
  what you need isn't there yet, hit the **+** button next to it to add a
  new one on the spot, no page reload.
- **Brand is scoped to Category** — pick "Power Supply" and the Brand
  dropdown filters (via a live AJAX call) to only brands that belong to
  Power Supply, e.g. "Dell PowerVault MD3600i Dual Ports". Each category
  keeps its own brand list. Also has its own **+** popup to add a new one.
- **Manufacturer is a separate, global list** — Dell, HP, HPE, etc., not
  scoped to a category (the same manufacturer makes many kinds of device).
  Same **+** popup pattern.
- **Totals are counted by Category, regardless of Brand** — a Dell SSD and
  an HP SSD both count toward the same "SSD" total on the Racks page,
  Dashboard, and Reports. Each individual unit still keeps its own brand,
  manufacturer, and other detail.
- **Each Category can have its own custom detail fields** — SSD might need
  Type/Capacity/Speed/Size, Power Supply might just need Capacity. Pick a
  category on the Add Device popup and its fields appear automatically;
  add a new field, rename one, or delete one right there (deleting only
  stops it being offered going forward — it doesn't erase values already
  saved on existing units).
- Every unit also tracks: **Part Number, Serial Number, Warehouse Number,
  Status** (Available / In Use / Reserved / Faulty), **Condition** (New /
  Used / Good / New Arrival), **Location** (free text, e.g. "Shelf 3, Bin
  A2"), **Description**, and is automatically stamped with **who added it
  and when** (date + time).
- Adding devices takes **one or more serial numbers at once** — everything
  else (category, brand, manufacturer, status, condition, part number,
  warehouse number, location, description, custom detail fields) is shared
  across them, and one row is created per serial number.

### Racks page
- Each rack's **total unit count sits next to the rack's own label/ID**
  (not buried inside a category row) — one clear number for "how much is
  in this rack."
- Devices are shown in an actual **table** inside each rack card (Category,
  Manufacturer, Brand, Serial, Status, Condition, Location), not loose
  chips — with a low-stock warning icon per category.
- **"Add device" opens a popup modal** instead of an inline form, with the
  cascading Category → Brand selects, the per-category custom detail
  fields described above, and all the **+** quick-add buttons.
- Deleting a rack or a unit pops a confirm modal right there on the page
  (you can still see everything behind it) instead of navigating away.

### Handover page
- The device picker is a real **table** with a checkbox column and a
  "select all," grouped by category with a running total per group, and a
  **live filter box** to narrow it by category/brand/serial as you type.
  Click anywhere on a row to toggle it, not just the checkbox.
- A live "Selected" panel shows full detail (category, manufacturer, brand,
  part number, serial, warehouse number, condition, rack) for everything
  you've checked, updating as you check/uncheck items.
- One submission produces **one printable web document** listing every
  item handed over together, plus a **downloadable Word (.docx) document**
  with the same item table and two signature blocks — "Handed over by
  (Warehouse)" and "Received by" — so both sides can sign a physical copy.
  No external service involved; it's generated server-side with
  `python-docx`.

### 🤖 AI assistant — fully local, no external API
- A small round button in the bottom-right corner on every page. Click it,
  a chat panel pops open right there.
- It's **not** calling Claude, OpenAI, or any external service — there's no
  API key, no network call, nothing to configure. `inventory/local_ai.py`
  answers by matching your question against a few patterns and running
  real Django queries against your own database:
  - *"where is the Dell power supply"* → locates matching units and their rack
  - *"who has the HP RAM"* / *"who took the label printer"* → handover history
  - *"how many SSDs do I have"* → counts
- It's scoped only to this system's data — it can't browse the web, can't
  answer general questions, and can't add/edit/delete anything.

### Everything else
- **Sidebar navigation** with icons, collapsing to an offcanvas menu on
  mobile.
- **Toast notifications** for success/error messages instead of a banner.
- **Dashboard** with a doughnut chart (units per rack), a handover trend
  line, and a top-categories bar chart (Chart.js).
- **QR labels + camera scanning** — every rack/device has a detail page
  with a printable QR code, and a **Scan** page that reads one with your
  camera and jumps straight there.
- **Real accounts + passkey login** — sign in with a password or register
  a passkey (Windows Hello / Touch ID / security key) from Settings.
- **Account management (superuser only)** — a dedicated Accounts page
  (linked from the sidebar and Settings, only visible to superusers) to
  create accounts, edit email/role/active status, reset a password, or
  delete an account. Guarded twice: the nav link only *shows* for
  superusers, but every view also checks `request.user.is_superuser`
  itself, so hiding the link is a convenience, not the real security
  boundary. You can't delete your own account, remove your own superuser
  status, or delete the last remaining superuser.
- **CSV + JSON export/import**, **pagination** on handover history and the
  activity log, and site-wide consistent table styling.
- **The AI assistant's "add a device" now works step-by-step** — say just
  "add a device" and it asks for the category, then the rack, remembering
  your answers across messages (stored in your session) until it has
  enough to create the unit. You can still give everything in one message
  too.
- **The chat bubble is draggable** — click and drag it anywhere on screen;
  its position is remembered (per-browser, via `localStorage`) across page
  loads.
- **Exposing this app through ngrok** — `python manage.py runserver_ngrok`
  starts a tunnel using your own ngrok API key and prints the public URL.
  See `inventory/management/commands/runserver_ngrok.py` and the
  `CSRF_TRUSTED_ORIGINS`/`ALLOWED_HOSTS` comments in `settings.py`.

## Setup

```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

python manage.py makemigrations inventory
python manage.py migrate
python manage.py createsuperuser

python manage.py runserver
```

Open http://127.0.0.1:8000/ and log in with the account you just created.
Nothing else needs configuring — the AI assistant works immediately with
no setup, and Category/Brand/Manufacturer lists start empty (add your first
ones from the Add Device popup on the Racks page).

If you'd rather start with some categories already in place, this will
seed the common ones from a shell:

```bash
python manage.py shell -c "from inventory.models import DeviceCategory, Manufacturer; DeviceCategory.ensure_defaults(); Manufacturer.ensure_defaults()"
```

## Configuration you'll want to check

In `rackinventory/settings.py`:

```python
WEBAUTHN_RP_ID = 'localhost'
WEBAUTHN_ORIGIN = 'http://localhost:8000'
```

`WEBAUTHN_RP_ID` must exactly match the domain the app is served from (no
scheme, no port) and `WEBAUTHN_ORIGIN` must match the full URL including
scheme — update both before deploying anywhere other than localhost, or
passkey registration/login will fail. Both of these — plus `ALLOWED_HOSTS`
and `CSRF_TRUSTED_ORIGINS` — update themselves automatically if you set a
`PUBLIC_ORIGIN` environment variable (see ngrok below), so most people
never need to hand-edit this file at all.

### Exposing this app publicly with ngrok

To reach this app from outside your own machine (e.g. to test passkeys or
camera scanning somewhere HTTPS is required, or just to share it), use
your own ngrok account:

```bash
pip install pyngrok        # not installed by default — see requirements.txt
export NGROK_AUTHTOKEN=your_token_here   # from https://dashboard.ngrok.com/get-started/your-authtoken
python manage.py runserver_ngrok
```

This starts a tunnel, prints the public `https://...ngrok-free.app` URL,
and automatically trusts it for `ALLOWED_HOSTS`/CSRF/WebAuthn for that run
— nothing to edit by hand. Your ngrok key never leaves your machine or
gets stored anywhere in this project; it's read once from the environment
variable and handed straight to the official `pyngrok` library. One thing
to know: a passkey registered while using `localhost` won't work on the
new ngrok domain (WebAuthn ties a passkey to the exact domain it was
registered on) — register a fresh one from Settings if you want passkey
login on the public URL.

## About the local AI assistant

`inventory/local_ai.py` is plain Python string/regex matching, not a
language model — it looks for trigger phrases ("where", "who has", "how
many"), pulls out the meaningful words from your message, and runs a
Django ORM query with them. That's the whole implementation; there's no
model weights, no tokenizer, no external call of any kind. This means:

- It's fast and free to run, and works with zero setup.
- It only understands the three question shapes described above (locate,
  who-handed-it-over, count) — it won't hold a general conversation or
  answer anything outside the inventory.
- It's easy to extend: add a new trigger-phrase list and a corresponding
  `_answer_*()` function in `local_ai.py` if you want it to recognize more
  kinds of questions later.

## About QR codes and camera scanning

- QR generation uses the `qrcode` Python package server-side — no API key
  needed, works offline.
- The Scan page uses the `html5-qrcode` JavaScript library from a CDN to
  read the camera feed client-side. Like WebAuthn, **camera access requires
  HTTPS in production** (localhost is exempted for development).

## Project layout

```
rack_inventory_django/
  manage.py
  rackinventory/            Django project (settings, root urls)
  inventory/                 The app
    models.py                 Rack, Device, Handover, ActivityLog,
                                AppSettings, WebAuthnCredential,
                                DeviceCategory, DeviceBrand, Manufacturer
    views.py                    All page logic + WebAuthn + quick-add +
                                  local AI assistant endpoints
    local_ai.py                  The local (no-API) assistant
    qr.py                         QR code PNG generation
    forms.py                       Validation for every form, including the
                                     quick-add popup forms
    urls.py                         URL routes
    middleware.py                    Login-required enforcement
    admin.py                          Django admin registration
    templates/inventory/                HTML templates (Bootstrap 5)
    static/inventory/
      custom.css                         Small additions on top of Bootstrap
      webauthn.js                         Passkey register/login JS helpers
```

## Notes on security

- Passwords are handled entirely by Django's built-in auth system (PBKDF2
  hashing, etc.) — nothing custom there.
- Passkey public keys are stored in `WebAuthnCredential`; private keys never
  leave the user's device, which is the point of WebAuthn.
- The AI assistant runs entirely inside your own server process against
  your own database — no data ever leaves the machine running this app for
  the assistant to work.
- `SECRET_KEY` in `rackinventory/settings.py` is a placeholder — change it
  and load it from an environment variable before deploying anywhere
  reachable outside your own machine.
- `DEBUG = True` and `ALLOWED_HOSTS = ['*']` are fine for local use only.
  Turn `DEBUG` off, set real `ALLOWED_HOSTS`, and serve over HTTPS before
  deploying (also required for passkeys and camera scanning to work
  outside localhost).
- There's no self-service signup page on purpose — accounts are created by
  whoever runs `createsuperuser` or uses `/admin/`.

## Extending it further

- Swap SQLite for Postgres: update `DATABASES` in `settings.py` and add
  `psycopg2-binary` to `requirements.txt`.
- Per-user activity attribution: `ActivityLog` currently logs actions
  without tying them to a specific user — add a `user` FK if you want to
  know who did what, not just what happened.
- Email alerts: a small management command checking the same grouping
  logic as the Reports page's low-stock table, sending mail, would fit
  well as a scheduled (cron/Celery) task.
- Teach the local assistant more question shapes by adding new trigger
  phrases and a handler function in `local_ai.py` — it's plain Python, no
  retraining or external service involved.

## A note on how this was built

I don't have internet access in the sandbox I build in, so none of this
was run against a live server — everything here is verified by static
analysis: every Python file compiles, every `{% url %}` in every template
is cross-checked against an actual URL name, every `{% include %}` points
at a real file, and I swept the whole project for leftover references to
fields from earlier versions of the schema (there were a few, now fixed).
That's a good sign, but it's not the same as clicking through it — please
give the core flows a real run (add a category/brand/manufacturer, add a
few units, submit a handover, try the assistant) once you've got it up
locally, and let me know if anything doesn't behave as described.
