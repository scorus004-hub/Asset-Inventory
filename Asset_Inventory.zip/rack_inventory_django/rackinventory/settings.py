from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: change this before deploying anywhere real, and load it
# from an environment variable instead of hardcoding it.
SECRET_KEY = 'django-insecure-change-this-key-before-any-real-deployment'

# SECURITY WARNING: keep DEBUG off in production.
DEBUG = True

ALLOWED_HOSTS = ['*']

# Django's CSRF protection checks the browser's Origin header against this
# list on POST requests. Without it, logging in (or any POST) over
# https://localhost:8000 — e.g. behind a local HTTPS proxy or tunnel — gets
# rejected with "Forbidden (Origin checking failed)". Add any other origin
# you actually serve this app from before deploying.
CSRF_TRUSTED_ORIGINS = [
    'http://localhost:8000',
    'https://localhost:8000',
    'http://127.0.0.1:8000',
    'https://127.0.0.1:8000',
    # Wildcards cover ngrok's randomly-generated free-tier subdomains
    # automatically, so a fresh `ngrok http 8000` usually just works.
    'https://*.ngrok-free.app',
    'https://*.ngrok.app',
    'https://*.ngrok.io',
]

# --- Exposing this app through ngrok (or any public domain) ---
# Get your own ngrok API key/authtoken at
# https://dashboard.ngrok.com/get-started/your-authtoken, then either:
#   1. Run `python manage.py runserver_ngrok` — starts an ngrok tunnel
#      using your NGROK_AUTHTOKEN and prints the public URL for you
#      (see inventory/management/commands/runserver_ngrok.py), or
#   2. Start ngrok yourself (`ngrok http 8000`) and set PUBLIC_ORIGIN to
#      the exact https URL it gives you before starting Django:
#        export PUBLIC_ORIGIN=https://your-subdomain.ngrok-free.app
# Either way, once PUBLIC_ORIGIN is set, ALLOWED_HOSTS, CSRF_TRUSTED_ORIGINS,
# and the WebAuthn (passkey) settings below all pick it up automatically —
# nothing else in this file needs editing by hand.
PUBLIC_ORIGIN = os.environ.get('PUBLIC_ORIGIN', '').rstrip('/')
PUBLIC_HOST = PUBLIC_ORIGIN.split('://')[-1].split('/')[0] if PUBLIC_ORIGIN else ''

if PUBLIC_HOST and PUBLIC_HOST not in ALLOWED_HOSTS and '*' not in ALLOWED_HOSTS:
    ALLOWED_HOSTS.append(PUBLIC_HOST)
if PUBLIC_ORIGIN and PUBLIC_ORIGIN not in CSRF_TRUSTED_ORIGINS:
    CSRF_TRUSTED_ORIGINS.append(PUBLIC_ORIGIN)

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'inventory',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    # Custom login-required middleware: keep this AFTER session/auth middleware.
    'inventory.middleware.LoginRequiredMiddleware',
]

LOGIN_URL = 'login'
LOGIN_REDIRECT_URL = 'dashboard'

ROOT_URLCONF = 'rackinventory.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'inventory.context_processors.active_tab',
            ],
        },
    },
]

WSGI_APPLICATION = 'rackinventory.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

AUTH_PASSWORD_VALIDATORS = []

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

STATIC_URL = 'static/'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# WebAuthn (passkey) relying-party settings. RP_ID must match the domain
# the app is served from (no scheme, no port) — "localhost" for local dev.
# These follow PUBLIC_ORIGIN automatically (see above) when you're running
# through ngrok; otherwise they default to localhost.
WEBAUTHN_RP_ID = PUBLIC_HOST or 'localhost'
WEBAUTHN_RP_NAME = 'Rack Inventory'
WEBAUTHN_ORIGIN = PUBLIC_ORIGIN or 'http://localhost:8000'

# The AI assistant (inventory/local_ai.py) is fully local — no API key,
# no network call, nothing to configure here.

